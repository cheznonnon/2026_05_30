//
//  AppDelegate.m
//  Pen Trainer
//
//  Created by のんのん on 2023/02/02.
//

#import "AppDelegate.h"




#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/draw.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/window.c"

#include "../../nonnon/mac/n_button.c"


#include "../../nonnon/bridge/gdi.c"




#include "canvas.c"




#define N_PENTRAINER_MODE_ROMAN    ( 0 )
#define N_PENTRAINER_MODE_HIRAGANA ( 1 )
#define N_PENTRAINER_MODE_KATAKANA ( 2 )
#define N_PENTRAINER_MODE_DIGIT    ( 3 )


NSString *n_pentrainer_table_roman[] = {

	@"A",
	@"a",
	
	@"B",
	@"b",
	
	@"C",
	@"c",
	
	@"D",
	@"d",
	
	@"E",
	@"e",
	
	@"F",
	@"f",
	
	@"G",
	@"g",
	
	@"H",
	@"h",
	
	@"I",
	@"i",
	
	@"J",
	@"j",

	@"K",
	@"k",

	@"L",
	@"l",

	@"M",
	@"m",

	@"N",
	@"n",

	@"O",
	@"o",

	@"P",
	@"p",

	@"Q",
	@"q",

	@"R",
	@"r",

	@"S",
	@"s",

	@"T",
	@"t",

	@"U",
	@"u",

	@"V",
	@"v",

	@"W",
	@"w",

	@"X",
	@"x",

	@"Y",
	@"y",

	@"Z",
	@"z",

	nil

};

NSString *n_pentrainer_table_hiragana[] = {

	@"あ",
	@"い",
	@"う",
	@"え",
	@"お",

	@"か",
	@"き",
	@"く",
	@"け",
	@"こ",

	@"さ",
	@"し",
	@"す",
	@"せ",
	@"そ",

	@"た",
	@"ち",
	@"つ",
	@"て",
	@"と",

	@"な",
	@"に",
	@"ぬ",
	@"ね",
	@"の",

	@"は",
	@"ひ",
	@"ふ",
	@"へ",
	@"ほ",

	@"ま",
	@"み",
	@"む",
	@"め",
	@"も",

	@"や",
	@"ゆ",
	@"よ",

	@"ら",
	@"り",
	@"る",
	@"れ",
	@"ろ",

	@"わ",
	@"を",

	@"ん",

	nil

};

NSString *n_pentrainer_table_katakana[] = {

	@"ア",
	@"イ",
	@"ウ",
	@"エ",
	@"オ",

	@"カ",
	@"キ",
	@"ク",
	@"ケ",
	@"コ",

	@"サ",
	@"シ",
	@"ス",
	@"セ",
	@"ソ",

	@"タ",
	@"チ",
	@"ツ",
	@"テ",
	@"ト",

	@"ナ",
	@"ニ",
	@"ヌ",
	@"ネ",
	@"ノ",

	@"ハ",
	@"ヒ",
	@"フ",
	@"ヘ",
	@"ホ",

	@"マ",
	@"ミ",
	@"ム",
	@"メ",
	@"モ",

	@"ヤ",
	@"ユ",
	@"ヨ",

	@"ラ",
	@"リ",
	@"ル",
	@"レ",
	@"ロ",

	@"ワ",
	@"ヲ",

	@"ン",

	nil

};

NSString *n_pentrainer_table_digit[] = {

	@"0",
	@"1",
	@"2",
	@"3",
	@"4",
	@"5",
	@"6",
	@"7",
	@"8",
	@"9",

	nil

};

void
n_pentrainer_character
(
	n_paint      *paint, 
	n_bmp        *bmp,
	n_type_gfx    size,
	n_posix_char *str,
	n_posix_char *font,
	u32           color_bg,
	u32           color_outline
)
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = size;
	gdi.sy                  = size;
	gdi.scale               = N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_SMOOTH;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = color_bg;
	gdi.base_color_fg       = color_bg;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.text                = str;
	gdi.text_font           = font;
	gdi.text_size           = size * 0.75;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;
	gdi.text_color_main     = color_bg;
	gdi.text_color_gradient = color_outline;

	gdi.text_effect_style[ 0 ] = N_GDI_EFFECT_OUTLINE;
	gdi.text_effect_color[ 0 ] = color_outline;
	gdi.text_effect_param[ 0 ] = 4;


	n_gdi_bmp( &gdi, bmp );
//n_bmp_save( bmp, "/Users/nonnon/Desktop/ret.bmp" );


	paint->pensize = ( gdi.text_size / 10 ) + 3;


	return;
}

void
n_pentrainer_character_move( n_paint *paint, int delta )
{

	if ( paint->mode == N_PENTRAINER_MODE_ROMAN )
	{
		paint->index += delta;
		if ( paint->index < 0 )
		{
			paint->index = 0;
			n_posix_loop
			{
				paint->index++;
				if ( n_pentrainer_table_roman[ paint->index ] == nil )
				{
					paint->index--;
					break;
				}
			}
		} else
		if ( n_pentrainer_table_roman[ paint->index ] == nil )
		{
			paint->index = 0;
		}
	} else
	if ( paint->mode == N_PENTRAINER_MODE_HIRAGANA )
	{
		paint->index += delta;
		if ( paint->index < 0 )
		{
			paint->index = 0;
			n_posix_loop
			{
				paint->index++;
				if ( n_pentrainer_table_hiragana[ paint->index ] == nil )
				{
					paint->index--;
					break;
				}
			}
		} else
		if ( n_pentrainer_table_hiragana[ paint->index ] == nil )
		{
			paint->index = 0;
		}
	} else
	if ( paint->mode == N_PENTRAINER_MODE_KATAKANA )
	{
		paint->index += delta;
		if ( paint->index < 0 )
		{
			paint->index = 0;
			n_posix_loop
			{
				paint->index++;
				if ( n_pentrainer_table_katakana[ paint->index ] == nil )
				{
					paint->index--;
					break;
				}
			}
		} else
		if ( n_pentrainer_table_katakana[ paint->index ] == nil )
		{
			paint->index = 0;
		}
	} else
	if ( paint->mode == N_PENTRAINER_MODE_DIGIT )
	{
		paint->index += delta;
		if ( paint->index < 0 )
		{
			paint->index = 0;
			n_posix_loop
			{
				paint->index++;
				if ( n_pentrainer_table_digit[ paint->index ] == nil )
				{
					paint->index--;
					break;
				}
			}
		} else
		if ( n_pentrainer_table_digit[ paint->index ] == nil )
		{
			paint->index = 0;
		}
	} else {
		return;
	}

	paint->color = n_bmp_color_mac( n_mac_nscolor2argb( [NSColor controlAccentColor ] ) );

	u32 color_bg;
	u32 color_fg = paint->color;

	if ( n_mac_is_darkmode() )
	{
		color_bg = n_mac_nscolor2argb( [NSColor blackColor ] );
	} else {
		color_bg = n_mac_nscolor2argb( [NSColor whiteColor ] );
	}

	NSFont       *nsfont    = paint->font;
	n_posix_char *font_name = n_mac_nsstring2str( [nsfont fontName] );
//NSLog( @"font_name : %s", font_name );

	n_posix_char *c = NULL;
	if ( paint->mode == N_PENTRAINER_MODE_ROMAN )
	{
		c = n_mac_nsstring2str( n_pentrainer_table_roman   [ paint->index ] );
	} else
	if ( paint->mode == N_PENTRAINER_MODE_HIRAGANA )
	{
		c = n_mac_nsstring2str( n_pentrainer_table_hiragana[ paint->index ] );
	} else
	if ( paint->mode == N_PENTRAINER_MODE_KATAKANA )
	{
		c = n_mac_nsstring2str( n_pentrainer_table_katakana[ paint->index ] );
	} else
	if ( paint->mode == N_PENTRAINER_MODE_DIGIT )
	{
		c = n_mac_nsstring2str( n_pentrainer_table_digit   [ paint->index ] );
	}

	n_pentrainer_character
	(
		paint,
		&paint->bmp_data,
		paint->canvas_size,
		c,
		font_name,
		color_bg,
		color_fg
	);

	n_string_free( font_name );


	return;
}




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonPaintCanvas *n_paint_canvas;

@property (weak) IBOutlet NSMenuItem *n_menu_roman;
@property (weak) IBOutlet NSMenuItem *n_menu_hiragana;
@property (weak) IBOutlet NSMenuItem *n_menu_katakana;
@property (weak) IBOutlet NSMenuItem *n_menu_digit;

@end




@implementation AppDelegate {

	n_paint paint;

}




- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d", event.keyCode );

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_ARROW_RIGHT :

		n_pentrainer_character_move( &paint,  1 );

		[_n_paint_canvas display_optimized];

	break;

	case N_MAC_KEYCODE_ARROW_LEFT :

		n_pentrainer_character_move( &paint, -1 );

		[_n_paint_canvas display_optimized];

	break;
/*
	case N_MAC_KEYCODE_F1 :
	{
		// [x] : warning raises : how to fix?

		NSFontManager *fontManager = [NSFontManager sharedFontManager];
		NSFontPanel   *fontPanel   = [fontManager fontPanel:YES];

		[fontPanel setPanelFont:paint.font isMultiple:NO];
		[fontPanel makeKeyAndOrderFront:self];
	}
	break;
*/
	} // switch

}
/*
- (NSFontPanelModeMask)validModesForFontPanel:(NSFontPanel *)fontPanel
{
	// [x] : deprecated

	return NSFontPanelCollectionModeMask;
}

- (void) changeFont:(id) sender
{
//NSLog( @"changeFont" );

	paint.font = [sender convertFont:paint.font];
//NSLog( @"%@", [paint.font fontName] );

	n_pentrainer_character_move( &paint, 0 );
	[_n_paint_canvas display_optimized];

}
*/
- (void) n_changeFont:(id) sender
{
//NSLog( @"changeFont" );

	paint.font = [sender convertFont:paint.font];
//NSLog( @"%@", [paint.font fontName] );

	n_pentrainer_character_move( &paint, 0 );
	[_n_paint_canvas display_optimized];

}

- (IBAction)n_menu_choose_font:(id)sender {

	// [x] : warning raises : how to fix?

	NSFontManager *fontManager = [NSFontManager sharedFontManager];
	NSFontPanel   *fontPanel   = [fontManager fontPanel:YES];

	[fontManager setAction:@selector(n_changeFont:)];

	[fontPanel setPanelFont:paint.font isMultiple:NO];
	[fontPanel makeKeyAndOrderFront:self];

}




- (IBAction)n_menu_roman:(id)sender {

	[_n_menu_roman    setState:NSControlStateValueOn ];
	[_n_menu_hiragana setState:NSControlStateValueOff];
	[_n_menu_katakana setState:NSControlStateValueOff];
	[_n_menu_digit    setState:NSControlStateValueOff];

	paint.index = 0;

	paint.mode = N_PENTRAINER_MODE_ROMAN;

	n_pentrainer_character_move( &paint, 0 );
	[_n_paint_canvas display_optimized];

}

- (IBAction)n_menu_hiragana:(id)sender {

	[_n_menu_roman    setState:NSControlStateValueOff];
	[_n_menu_hiragana setState:NSControlStateValueOn ];
	[_n_menu_katakana setState:NSControlStateValueOff];
	[_n_menu_digit    setState:NSControlStateValueOff];

	if ( paint.mode == N_PENTRAINER_MODE_HIRAGANA ) { } else
	if ( paint.mode != N_PENTRAINER_MODE_KATAKANA ) { paint.index = 0; }

	paint.mode = N_PENTRAINER_MODE_HIRAGANA;

	n_pentrainer_character_move( &paint, 0 );
	[_n_paint_canvas display_optimized];

}

- (IBAction)n_menu_katakana:(id)sender {

	[_n_menu_roman    setState:NSControlStateValueOff];
	[_n_menu_hiragana setState:NSControlStateValueOff];
	[_n_menu_katakana setState:NSControlStateValueOn ];
	[_n_menu_digit    setState:NSControlStateValueOff];

	if ( paint.mode == N_PENTRAINER_MODE_KATAKANA ) { } else
	if ( paint.mode != N_PENTRAINER_MODE_HIRAGANA ) { paint.index = 0; }

	paint.mode = N_PENTRAINER_MODE_KATAKANA;

	n_pentrainer_character_move( &paint, 0 );
	[_n_paint_canvas display_optimized];

}

- (IBAction)n_menu_digit:(id)sender {

	[_n_menu_roman    setState:NSControlStateValueOff];
	[_n_menu_hiragana setState:NSControlStateValueOff];
	[_n_menu_katakana setState:NSControlStateValueOff];
	[_n_menu_digit    setState:NSControlStateValueOn ];

	paint.index = 0;

	paint.mode = N_PENTRAINER_MODE_DIGIT;

	n_pentrainer_character_move( &paint, 0 );
	[_n_paint_canvas display_optimized];

}



- (void) NonnonPaintResize
{

	CGFloat dsx,dsy; n_mac_desktop_size( &dsx, &dsy );
//NSLog( @"%0.2f %0.2f", dsx, dsy );

	paint.canvas_size = n_posix_min_n_type_real( dsx, dsy ) * 0.20;
	paint.canvas_size = (int) paint.canvas_size / 8 * 8;


	n_pentrainer_character_move( &paint, 0 );

	paint.pen_bmp_data = &paint.bmp_data;
	paint.pen_bmp_grab = &paint.bmp_grab;


	paint.inner_sx = paint.canvas_size;
	paint.inner_sy = paint.canvas_size;

	paint.margin = n_posix_min_n_type_real( dsx, dsy ) * 0.125;


	CGFloat sx = N_BMP_SX( &paint.bmp_data );
	CGFloat sy = N_BMP_SY( &paint.bmp_data );
//NSLog( @"%0.2f %0.2f", sx, sy );

	sx += paint.margin;
	sy += paint.margin;


	//[self NonnonPaintZoomUI];

	[_window setContentSize:NSMakeSize( sx,sy )];
	n_mac_window_centering( _window );

	[_n_paint_canvas setFrame:NSMakeRect( 0,0,sx,sy )];
	[_n_paint_canvas display_optimized];


	{
		CGFloat ico = paint.margin / 2 * 0.75;

		paint.clear_rect = NSMakeRect( ( sx - ico ) / 2, 0, ico, ico );

		paint.prev_rect = NSMakeRect( paint.clear_rect.origin.x - ico, 0, ico, ico );
		paint.next_rect = NSMakeRect( paint.clear_rect.origin.x + ico, 0, ico, ico );

		paint.icon_size = ico;
	}

}

- (void) NonnonPaintStatus
{
	return;
}




- (void) PenTrainerSettings : (BOOL) is_read
{

	NSString *nsstr;

	if ( is_read )
	{

		nsstr = n_mac_settings_read( @"font" );

		paint.font = [NSFont fontWithName:nsstr size:15];
		if ( paint.font == NULL )
		{
			paint.font = [NSFont fontWithName:@"HiraMaruProN-W4" size:15];
		}


		nsstr = n_mac_settings_read( @"mode" );

		paint.mode = [nsstr intValue];

		if ( paint.mode == N_PENTRAINER_MODE_ROMAN )
		{
			[_n_menu_roman    setState:NSControlStateValueOn ];
			[_n_menu_hiragana setState:NSControlStateValueOff];
			[_n_menu_katakana setState:NSControlStateValueOff];
			[_n_menu_digit    setState:NSControlStateValueOff];
		} else
		if ( paint.mode == N_PENTRAINER_MODE_HIRAGANA )
		{
			[_n_menu_roman    setState:NSControlStateValueOff];
			[_n_menu_hiragana setState:NSControlStateValueOn ];
			[_n_menu_katakana setState:NSControlStateValueOff];
			[_n_menu_digit    setState:NSControlStateValueOff];
		} else
		if ( paint.mode == N_PENTRAINER_MODE_KATAKANA )
		{
			[_n_menu_roman    setState:NSControlStateValueOff];
			[_n_menu_hiragana setState:NSControlStateValueOff];
			[_n_menu_katakana setState:NSControlStateValueOn ];
			[_n_menu_digit    setState:NSControlStateValueOff];
		} else
		if ( paint.mode == N_PENTRAINER_MODE_DIGIT )
		{
			[_n_menu_roman    setState:NSControlStateValueOff];
			[_n_menu_hiragana setState:NSControlStateValueOff];
			[_n_menu_katakana setState:NSControlStateValueOff];
			[_n_menu_digit    setState:NSControlStateValueOn ];
		} else {
			paint.mode = N_PENTRAINER_MODE_HIRAGANA;
			[_n_menu_roman    setState:NSControlStateValueOff];
			[_n_menu_hiragana setState:NSControlStateValueOn ];
			[_n_menu_katakana setState:NSControlStateValueOff];
			[_n_menu_digit    setState:NSControlStateValueOff];
		}

	} else {

		n_mac_settings_write( @"font", [paint.font fontName] );

		nsstr = [NSString stringWithFormat:@"%d", paint.mode];
		n_mac_settings_write( @"mode", nsstr );

	}

}

-(void) PenTrainerThemedIcon:(NSString*)str bmp:(n_bmp*)bmp
{

	n_bmp_free( bmp );

	n_mac_image_rc_load_bmp( str, bmp );

	n_mac_button_system_themed( bmp );

	n_bmp_mac_color( bmp );

}



- (void)awakeFromNib
{

	// [!] : Instance

	n_paint_zero( &paint );


	n_mac_image_window = _window;
	n_gdi_scale_factor = n_mac_image_window.backingScaleFactor;


	//paint.font = [NSFont boldSystemFontOfSize:12];
	//paint.font = [NSFont fontWithName:@"HiraMaruProN-W4" size:15];
	[self PenTrainerSettings:YES];


	{

		//paint.pensize = 12; // later set
		paint.mix     = 20;
		//paint.color   = n_bmp_color_mac( n_mac_nscolor2argb( [NSColor controlAccentColor ] ) );

		paint.grid_onoff = TRUE;

	}


	paint.queue = [[NSOperationQueue alloc] init];
	paint.cores = n_posix_cpu_count();

	paint.zoom   = 1;
	paint.scroll = NSMakePoint( 0, 0 );

	_n_paint_canvas.delegate = self;
	_n_paint_canvas.paint    = &paint;


	[self NonnonPaintResize];

	[self n_timer_method_color];


	[[NSNotificationCenter defaultCenter]
	      addObserver:self
		 selector:@selector( windowWillClose: )
		     name:NSWindowWillCloseNotification
		   object:nil
	];

	[[NSDistributedNotificationCenter defaultCenter]
		addObserver:self
		   selector:@selector( accentColorChanged: )
		       name:@"AppleColorPreferencesChangedNotification"
		     object:nil
	];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	[self PenTrainerSettings:NO];
	
	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}

}

- (void) n_timer_method_color
{

	[self PenTrainerThemedIcon:@"rc/back"    bmp:&paint. prev_bmp];
	[self PenTrainerThemedIcon:@"rc/new"     bmp:&paint.clear_bmp];
	[self PenTrainerThemedIcon:@"rc/forward" bmp:&paint. next_bmp];

	n_bmp_resizer( &paint. prev_bmp, paint.icon_size, paint.icon_size, 0, N_BMP_RESIZER_CENTER );
	n_bmp_resizer( &paint.clear_bmp, paint.icon_size, paint.icon_size, 0, N_BMP_RESIZER_CENTER );
	n_bmp_resizer( &paint. next_bmp, paint.icon_size, paint.icon_size, 0, N_BMP_RESIZER_CENTER );

	n_pentrainer_character_move( &paint, 0 );
	[_n_paint_canvas display_optimized];

}

- (void) accentColorChanged:(NSNotification *)notification
{
//NSLog( @"accentColorChanged" );

	// [x] : buggy : system calls without accent color change

	n_mac_timer_init_once( self, @selector( n_timer_method_color ), 200 );

}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}


@end
