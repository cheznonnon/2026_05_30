// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_paint_grabber_pixel_get( n_type_gfx tx, n_type_gfx ty, u32 picked, u32 *before, u32 *after, n_type_real blend )
{

	n_paint *p = n_paint_global.paint;


	u32 color_b, color_a;


	// [x] : don't use _fast()

	n_bmp_ptr_get( p->pen_bmp_data, tx,ty, &color_b );

	color_a = picked;


	if ( before != NULL ) { (*before) = color_b; }
	if ( after  != NULL ) { (*after ) = color_a; }


	return;
}

// internal
void
n_paint_grabber_pixel_set( n_type_gfx tx, n_type_gfx ty, u32 before, u32 after )
{

	n_paint *p = n_paint_global.paint;


	if ( before == after ) { return; }


	n_bmp_ptr_set( p->pen_bmp_data, tx,ty, after );


	return;
}




// internal
n_type_real
n_paint_pen_edge( n_type_gfx x, n_type_gfx y, s32 r, n_type_real coeff, n_type_real blend )
{
	return coeff * blend;
}




void
n_paint_pen_display( n_type_gfx px, n_type_gfx py, n_type_gfx radius )
{
//[n_paint_global display]; return;

	n_paint *p = n_paint_global.paint;


	radius++;

	n_type_gfx  x = px - radius;
	n_type_gfx  y = py - radius;
	n_type_gfx sx = radius * 2;
	n_type_gfx sy = radius * 2;

	[n_paint_global n_paint_convert_bitmap2canvas:nil x:&x y:&y sx:&sx sy:&sy];

	NSRect rect = NSMakeRect( x,y,sx,sy );

	p->redraw_type = N_PAINT_REDRAW_TYPE_PEN;

	[n_paint_global displayRect:rect];


	return;
}

// internal
void
n_paint_pen_engine( n_type_gfx fx, n_type_gfx fy, n_type_real blend )
{

	n_paint *p = n_paint_global.paint;


	if ( blend == 0.0 ) { return; }


	n_type_gfx radius = p->pen_radius;
	u32        color  = p->pen_color;


	radius++;


	n_type_gfx x = -radius;
	n_type_gfx y = -radius;
	n_posix_loop
	{

		n_type_real coeff;

		if ( n_bmp_ellipse_detect_coeff( x,y, radius,radius, &coeff ) )
		{

			if ( coeff != 0.0 )
			{

				n_type_gfx tx = fx + x;
				n_type_gfx ty = fy + y;


				// [!] : don't use -1 == 0xffffffff == n_bmp_argb( 255,255,255,255 )

				u32 color_f = color + 1;
				u32 color_t = color;


				n_paint_grabber_pixel_get( tx,ty, color, &color_f, &color_t, 0.00 );
				coeff = n_paint_pen_edge( x,y, radius, coeff, blend );

				u32 color_ret = n_bmp_blend_pixel_force_move( color_f, color_t, coeff );
				n_paint_grabber_pixel_set( tx,ty, color_f, color_ret );
			}

		}


		x++;
		if ( x > radius )
		{

			x = -radius;

			y++;
			if ( y > radius ) { break; }
		}

	}


	n_paint_pen_display( fx,fy, p->pen_radius );


	return;
}




#define N_PAINT_PEN_START 0
#define N_PAINT_PEN_LOOP  1
#define N_PAINT_PEN_STOP  2

#define n_paint_pen_start( pt ) n_paint_pen( pt, N_PAINT_PEN_START )
#define n_paint_pen_loop(  pt ) n_paint_pen( pt, N_PAINT_PEN_LOOP  )
#define n_paint_pen_stop(  pt ) n_paint_pen( pt, N_PAINT_PEN_STOP  )

void
n_paint_pen( NSPoint pt, int mode )
{

	n_paint *p = n_paint_global.paint;


	static n_type_gfx px;
	static n_type_gfx py;


	n_type_gfx fx,fy;
	n_type_gfx tx,ty;

	tx = pt.x;
	ty = pt.y;

	if ( mode == N_PAINT_PEN_START )
	{

		p->pen_start_x = px = fx = tx;
		p->pen_start_y = py = fy = ty;

	} else {

		if ( mode == N_PAINT_PEN_STOP )
		{
			if ( ( p->pen_start_x == tx )&&( p->pen_start_y == ty ) ) { return; }
		}

		fx = px;
		fy = py;

	}


	if (
		( mode == N_PAINT_PEN_LOOP )
		&&
		( p->pen_blend != 1.0 )
	)
	{

		// [!] : nothing to do

		if ( ( fx == tx )&&( fy == ty ) ) { return; }

	}


	if ( p->pen_blend == 1.0 )
	{
		n_bmp_pen_bresenham( fx,fy, tx,ty, p->pen_blend, n_paint_pen_engine );
	} else {
		n_bmp_pen_wu       ( fx,fy, tx,ty, p->pen_blend, n_paint_pen_engine );
	}

	px = tx;
	py = ty;


	return;
}

void
NonnonPaintPen_mouseDown( void )
{

	n_paint *p = n_paint_global.paint;


	if ( p->tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( p->pen_start == FALSE )
		{

			// [!] : pre-calculate

			p->pen_radius = p->pensize / 2;
			p->pen_color  = p->color;
			p->pen_blend  = (n_type_real) p->mix * 0.01;


			// [!] : the first input
//NSLog( @"Pen Start" );
			p->pen_start = TRUE;

			n_paint_pen_start( [n_paint_global n_paint_canvaspos] );

		}

	}

}

void
NonnonPaintPen_mouseDragged( void )
{

	n_paint *p = n_paint_global.paint;


	if ( p->tooltype == N_PAINT_TOOL_TYPE_PEN )
	{
		if ( p->pen_start )
		{
//NSLog( @"Pen Loop" );
			n_paint_pen_loop( [n_paint_global n_paint_canvaspos] );

		}
	}

}

void
NonnonPaintPen_mouseUp( void )
{

	n_paint *p = n_paint_global.paint;


	if ( p->tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( p->pen_start )
		{
//NSLog( @"Pen Stop" );
			n_paint_pen_stop( [n_paint_global n_paint_canvaspos] );
			p->pen_start = FALSE;

		}
	}

}


