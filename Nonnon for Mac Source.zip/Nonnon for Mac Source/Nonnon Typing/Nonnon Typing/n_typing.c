// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/neutral/bmp/ui/timer.c"
#include "../../nonnon/neutral/bmp/ui/transition.c"

#include "../../nonnon/bridge/gdi.c"




#define N_TYPING_CANVAS_SIZE ( 256 )


#define N_TYPING_CANVAS_COLOR_DARK n_bmp_rgb( 111,111,111 )
#define N_TYPING_CANVAS_COLOR_LITE n_bmp_rgb( 222,222,222 )


#define N_TYPING_MODE_WARM_UP ( 0 )
#define N_TYPING_MODE_TRAINER ( 1 )
#define N_TYPING_MODE_FREE    ( 2 )




NSString *n_typing_trainer_warm_up_table[] = {

	@"f", @"g", @"f", @"g",
	@"f", @"d", @"f", @"d",
	@"f", @"s", @"f", @"s",
	@"f", @"a", @"f", @"a",

	@"Space",

	@"j", @"h", @"j", @"h",
	@"j", @"k", @"j", @"k",
	@"j", @"l", @"j", @"l",

	@"Space",

	@"f", @"b", @"f", @"b",
	@"f", @"v", @"f", @"v",
	@"f", @"c", @"f", @"c",
	@"f", @"x", @"f", @"x",
	@"f", @"z", @"f", @"z",

	@"Space",

	@"j", @"n", @"j", @"n",
	@"j", @"m", @"j", @"m",

	@"Space",

	@"f", @"t", @"f", @"t",
	@"f", @"r", @"f", @"r",
	@"f", @"e", @"f", @"e",
	@"f", @"w", @"f", @"w",
	@"f", @"q", @"f", @"q",

	@"Space",

	@"j", @"y", @"j", @"y",
	@"j", @"u", @"j", @"u",
	@"j", @"i", @"j", @"i",
	@"j", @"o", @"j", @"o",
	@"j", @"p", @"j", @"p",

	@"Space",

	@"f", @"1", @"f", @"1",
	@"f", @"2", @"f", @"2",
	@"f", @"3", @"f", @"3",
	@"f", @"4", @"f", @"4",
	@"f", @"5", @"f", @"5",
	@"f", @"6", @"f", @"6",

	@"Space",

	@"j", @"7", @"j", @"7",
	@"j", @"8", @"j", @"8",
	@"j", @"9", @"j", @"9",
	@"j", @"0", @"j", @"0",

	@"Return",

	NULL

};

NSString*
n_typing_trainer_warm_up( void )
{

	static int i = 0;

	NSString *nsstr = n_typing_trainer_warm_up_table[ i ];

	i++;

	if ( n_typing_trainer_warm_up_table[ i ] == NULL )
	{
		i = 0;
	}


	return nsstr;
}




char n_typing_trainer_shuffle_table_left[] = {

	'q', 'w', 'e', 'r', 't',
	'a', 's', 'd', 'f', 'g',
	'z', 'x', 'c', 'v', 'b',

};

char n_typing_trainer_shuffle_table_right[] = {

	'-',
	'y', 'u', 'i', 'o', 'p',
	'h', 'j', 'k', 'l',
	'n', 'm', ',', '.',

};

NSString*
n_typing_trainer_shuffle( void )
{

	static int step = 1;


	NSString *nsstr;

	int random = n_random_range( 100 );

	if ( ( step % 50 ) == 0 )
	{
		nsstr = @"Return";
	} else
	if ( ( step % 10 ) == 0 )
	{
		nsstr = @"Space";
	} else
	if ( random < 5 )
	{
		nsstr = @"Backspace";
	} else
	if ( random < 30 )
	{
		int f = '0';
		int t = '9';

		int r = t - f;

		char str[ 2 ] = { f + n_random_range( r ), N_STRING_CHAR_NUL };

		nsstr = n_mac_str2nsstring( str );
	} else {
		char str[ 2 ] = { N_STRING_CHAR_NUL, N_STRING_CHAR_NUL };

		random = n_random_range( 10 );
		if ( random < 4 )
		{
//NSLog( @"left" );
			str[ 0 ] = n_typing_trainer_shuffle_table_left [ n_random_range( 15 ) ];
		} else {
//NSLog( @"right" );
			str[ 0 ] = n_typing_trainer_shuffle_table_right[ n_random_range( 14 ) ];
		}

		nsstr = n_mac_str2nsstring( str );
	}


	step++;


	return nsstr;
}




typedef struct {

	NonnonGame   *self;
	NSPoint       pt;
	n_bmp         canvas_base;
	n_bmp         canvas; // [!] : alias of NSBitmapImageRep
	BOOL          refresh;

	NSBitmapImageRep *rep;

	n_type_gfx    sx,sy;

	int           mode;

	int           baseline;

	BOOL          is_single_char;

	BOOL          trainer_input;
	int           trainer_index;

	NSString     *string_cur;
	NSString     *string_prv;
	NSString     *string_ans;
	NSString     *string_reg;

	BOOL          transition_onoff;
	n_bmp         transition_bmp_old;
	n_bmp         transition_bmp_new;
	n_type_real   transition_percent;
	BOOL          transition_event;
	BOOL          transition_special;
	int           transition_blink_phase;
	u32           transition_msec;

	NSMenuItem   *n_menu_warm_up;
	NSMenuItem   *n_menu_trainer;
	NSMenuItem   *n_menu_free;

	BOOL          chip_onoff;
	u32           chip_timeout;
	n_bmp         chip_bmp_bg;
	n_bmp         chip_bmp_fg;

} n_typing;




u32
n_typing_color_bg( n_typing *p )
{
	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		return N_TYPING_CANVAS_COLOR_DARK;
	} else
	if ( p->mode == N_TYPING_MODE_TRAINER )
	{
		return N_TYPING_CANVAS_COLOR_DARK;
	} else {
		return N_TYPING_CANVAS_COLOR_LITE;
	}
}

u32
n_typing_color_fg( n_typing *p )
{
	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		return n_bmp_white;
	} else
	if ( p->mode == N_TYPING_MODE_TRAINER )
	{
		return N_TYPING_CANVAS_COLOR_LITE;
	} else {
		return N_TYPING_CANVAS_COLOR_DARK;
	}
}

void
n_typing_gdi( n_typing *p, n_bmp *bmp, NSString *str, BOOL is_single_char, u32 color_text )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	n_type_gfx factor = 1;

	if ( is_single_char )
	{
		factor = 1;
	} else {
		factor = 2;
		if ( [str length] >= 3 )
		{
			factor = ceil( (CGFloat) [str length] / 2 );
		}
	}

	gdi.sx                  = N_TYPING_CANVAS_SIZE;
	gdi.sy                  = N_TYPING_CANVAS_SIZE;
	gdi.scale               = N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_typing_color_bg( p );
	gdi.base_color_fg       = n_typing_color_fg( p );
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	if ( p->mode == N_TYPING_MODE_WARM_UP )
	{
		gdi.base_style = N_GDI_BASE_VERTICAL;
	}

	gdi.text                = n_mac_nsstring2str( str );
	gdi.text_font           = n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = ( N_TYPING_CANVAS_SIZE / 2 ) / factor;
	gdi.text_style          = p->baseline;
	gdi.text_color_main     = color_text;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	n_string_free( gdi.text );


	return;
}




void
n_typing_sound_play( n_mac_sound2 *p )
{

	n_mac_sound2_stop( p );
	n_mac_sound2_play( p );

	return;
}




// [!] : this is important to play

n_mac_sound2 n_typing_snd[ 2 + 1 + 6 ];




#define n_typing_zero( p ) n_memory_zero( p, sizeof( n_typing ) )

void
n_typing_init( n_typing *p )
{

	// Global

	n_bmp_safemode = FALSE;

	n_bmp_transparent_onoff_default = FALSE;

	//n_bmp_flip_onoff = TRUE;

	n_random_shuffle();


	// Instance

	n_bmp_new( &p->canvas_base, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );

	p->rep = n_mac_image_NSBitmapImageRep( &p->canvas_base );
	n_mac_image_imagerep_alias( p->rep, &p->canvas );


	n_mac_sound2_init( &n_typing_snd[ 0 ], @"answer_o"       , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 1 ], @"answer_x"       , @"wav" );

	n_mac_sound2_init( &n_typing_snd[ 2 ], @"carriage_return", @"mp3" );

	n_mac_sound2_init( &n_typing_snd[ 3 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 4 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 5 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 6 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 7 ], @"typewriter"     , @"wav" );
	n_mac_sound2_init( &n_typing_snd[ 8 ], @"typewriter"     , @"wav" );

	n_typing_snd[ 0 ].mixer.volume = 0.5;
	n_typing_snd[ 1 ].mixer.volume = 0.5;


	return;
}

void
n_typing_exit( n_typing *p )
{
	return;
}

void
n_typing_loop( n_typing *p )
{

	if (
		( p->mode == N_TYPING_MODE_WARM_UP )
		||
		( p->mode == N_TYPING_MODE_TRAINER )
	)
	{

		if ( p->transition_onoff )
		{
			//
		} else
		if ( p->trainer_input )
		{
			p->trainer_input = FALSE;

			if ( [p->string_cur compare:p->string_ans] == 0 )
			{
				if ( p->mode == N_TYPING_MODE_WARM_UP )
				{
					p->string_cur = n_typing_trainer_warm_up();
				} else {
					p->string_cur = n_typing_trainer_shuffle();
				}

				p->is_single_char = ( 1 == [p->string_cur length] );

				n_typing_sound_play( &n_typing_snd[ 0 ] );

				p->transition_event = TRUE;
			} else {
				n_typing_sound_play( &n_typing_snd[ 1 ] );

				if ( p->chip_onoff == FALSE )
				{
					p->chip_onoff   = TRUE;
					p->chip_timeout = n_posix_tickcount();

					u32 color = n_bmp_rgb_mac( 255,0,128 );
					n_typing_gdi( p, &p->chip_bmp_fg, p->string_ans, ( 1 == [p->string_ans length] ), color );

					n_bmp_flush_transcopy( &p->chip_bmp_fg, &p->canvas );
					p->refresh = TRUE;
				}
			}
		}
	} else
	if ( p->mode == N_TYPING_MODE_FREE )
	{
		if ( p->trainer_input )
		{
			p->trainer_input = FALSE;

			if ( [p->string_cur compare:@"Return"] == 0 )
			{
//static int i = 0; NSLog( @"Return : %d", i ); i++;
				n_typing_sound_play( &n_typing_snd[ 2 ] );
			} else {
				static int jam = 0;
				n_typing_sound_play( &n_typing_snd[ 2 + 1 + ( jam % 6 ) ] );
				jam++;
			}

			p->transition_event = TRUE;
		}
	}



	// [!] : Shared

	if ( p->transition_event )
	{
		p->transition_event = FALSE;

		p->transition_onoff = TRUE;

		if ( p->transition_special )
		{
			n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

			n_bmp_new( &p->transition_bmp_new, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );
			n_bmp_flush( &p->transition_bmp_new, n_typing_color_bg( p ) );
		} else
		if ( 0 != [p->string_cur compare:p->string_prv] )
		{
			n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

			n_typing_gdi( p, &p->transition_bmp_new, p->string_cur, p->is_single_char, n_typing_color_fg( p ) );
		} else {
			p->transition_blink_phase = 1;
		}
	}

	if ( p->transition_blink_phase == 1 )
	{
		p->transition_blink_phase = 2;

		n_bmp_carboncopy( &p->canvas, &p->transition_bmp_old );

		n_bmp_new( &p->transition_bmp_new, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );
		n_bmp_flush( &p->transition_bmp_new, n_typing_color_bg( p ) );
	} else
	if ( p->transition_blink_phase == 2 )
	{
		if ( p->transition_onoff == FALSE )
		{
			p->transition_blink_phase = 0;

			p->transition_onoff = TRUE;

			n_bmp_new( &p->transition_bmp_old, N_TYPING_CANVAS_SIZE, N_TYPING_CANVAS_SIZE );
			n_bmp_flush( &p->transition_bmp_old, n_typing_color_bg( p ) );

			n_typing_gdi( p, &p->transition_bmp_new, p->string_cur, p->is_single_char, n_typing_color_fg( p ) );
		}
	}

	if ( p->transition_onoff )
	{
		BOOL ret = n_bmp_ui_transition
		(
			&p->canvas,
			&p->transition_bmp_old, 
			&p->transition_bmp_new,
			 p->transition_msec,
			&p->transition_percent,
			N_BMP_UI_TRANSITION_FADE
		);

		if ( ret )
		{
			p->transition_onoff = FALSE;

			n_bmp_free( &p->transition_bmp_old );
			n_bmp_free( &p->transition_bmp_new );

			p->string_prv = p->string_cur;

			n_bmp_free( &p->chip_bmp_bg );
			n_bmp_carboncopy( &p->canvas, &p->chip_bmp_bg );

			p->transition_special = FALSE;
		}

		p->refresh = TRUE;
	}


	if ( p->chip_onoff )
	{
		if ( n_bmp_ui_timer( &p->chip_timeout, 333 ) )
		{
			p->chip_onoff = FALSE;

			n_bmp_flush_transcopy( &p->chip_bmp_bg, &p->canvas );
			p->refresh = TRUE;
		}
	}


	return;
}


