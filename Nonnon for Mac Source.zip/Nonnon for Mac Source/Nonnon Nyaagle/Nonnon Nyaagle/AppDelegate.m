//
//  AppDelegate.m
//  Nyaagle
//
//  Created by のんのん on 2023/02/10.
//

#import "AppDelegate.h"



#include "../../nonnon/mac/n_textfield.c"
#include "../../nonnon/mac/n_txtbox.c"

#include "../../nonnon/neutral/bmp/ui/search_icon.c"


#include "engine.c"




@interface NyaagleImageView: NSImageView

@property (nonatomic,assign) id delegate;

@end

@implementation NyaagleImageView

@synthesize delegate;

- init
{
	self = [super init];
	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];
	}

	return self;
}




-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstr      = [[NSURL URLFromPasteboard:pasteboard] path];

	[self.delegate NonnonDragAndDrop_dropped:nsstr];

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	return NSDragOperationCopy;
}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( theEvent.clickCount >= 2 )
	{
		//[self.window zoom:self.window];

		NSRect rect = [self.window frame];

		CGFloat large_size = 777;

		rect.origin.x    -= ( large_size - rect.size.width  ) / 2;
		rect.origin.y    -= ( large_size - rect.size.height ) / 2;
		rect.size.width  = large_size;
		rect.size.height = large_size;

		[self.window setFrame:rect display:YES animate:YES];

		return;
	}

	[self.window performWindowDragWithEvent:theEvent];

}

@end




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NyaagleImageView *n_logo;
@property (weak) IBOutlet NonnonTextField  *n_path;
@property (weak) IBOutlet NonnonTxtbox     *n_search;
@property (weak) IBOutlet NonnonTxtbox     *n_list;
@property (weak) IBOutlet NSMenuItem       *n_menu_file_name_only;

@end




@implementation AppDelegate {

	BOOL  n_is_option_pressed;

}




- (void) NyaagleLogo:(BOOL) is_text_search
{

	NSString *name;
	if ( is_text_search )
	{
		name = @"nyaagle_logo";
	} else {
		if ( n_mac_is_darkmode() )
		{
			name = @"nyaagle_logo_name_dark";
		} else {
			name = @"nyaagle_logo_name";
		}
	}

	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:name ofType:@"png"];

	NSImage  *img  = [[NSImage alloc] initWithContentsOfFile:path];

	_n_logo.image = img;

}

- (void) NyaagleGo
{

	_n_list.txtbox->focus = -1;


	[[NSCursor operationNotAllowedCursor] set];


	n_posix_char *path  = n_mac_nsstring2str( [_n_path stringValue] );
	n_posix_char *query = n_txt_get( _n_search.txtbox->txt_data, 0 );

	// [Needed] : sandbox off

	if ( n_posix_stat_is_file( path ) )
	{
		n_posix_char *upper = n_string_path_upperfolder_new( path );
		n_string_free( path );
		path = upper;
	}


	if ( FALSE == n_string_is_empty( query ) )
	{
		NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
		[pasteboard clearContents];
		[pasteboard writeObjects:@[ n_mac_str2nsstring( query ) ]];
	}


	BOOL prv_search = n_nyaagle_is_text_search;

	if ( n_is_option_pressed )
	{
		n_nyaagle_is_text_search = FALSE;
	}

	[_n_list NonnonTxtboxReset];

	if (
		( _n_list.txtbox->txt_data->sy == 1 )
		&&
		( n_string_is_empty( n_txt_get( _n_list.txtbox->txt_data, 0 ) ) )
	)
	{
		n_txt_utf8_new( _n_list.txtbox->txt_data );
		n_nyaagle_directory( _n_list.txtbox->txt_data, path, query );
	} else {
		n_nyaagle_directory_narrowed( _n_list.txtbox->txt_data, query );
	}


	n_nyaagle_is_text_search = prv_search;


	n_txt_sort_up( _n_list.txtbox->txt_data );

	[_n_list display];


	n_string_free( path );


	[[NSCursor arrowCursor] set];


	return;
}

- (void) NonnonTxtbox_delegate_edited:(NonnonTxtbox*)txtbox onoff:(BOOL)onoff
{

	if ( txtbox == _n_search )
	{

		if ( _n_search.txtbox->is_enter_pressed )
		{
			[self NyaagleGo];
		}

	}

}

- (void) NonnonTxtbox_delegate_F3:(NonnonTxtbox*)txtbox is_left:(BOOL)is_left
{
//NSLog( @"NonnonTxtbox_delegate_F3" );

	[self NyaagleGo];

}

- (void) NonnonTxtbox_delegate_delete:(NonnonTxtbox*)txtbox
{
//NSLog( @"NonnonTxtbox_delegate_delete" );

	n_txt_utf8_new( _n_list.txtbox->txt_data );
	[_n_list NonnonTxtboxReset];

	[_n_list display];

}

- (void) NonnonTxtbox_delegate_shift:(NSEvent*) event
{
//NSLog( @"NonnonTxtbox_delegate_shift" );

	if ( n_nyaagle_is_text_search == FALSE ) { return; }

	if ( event.modifierFlags & NSEventModifierFlagOption )
	{
		n_is_option_pressed = TRUE;
		[self NyaagleLogo: NO];
	} else {
		n_is_option_pressed = FALSE;
		[self NyaagleLogo:YES];
	}


	return;
}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( [theEvent clickCount] == 2 )
	{
		n_posix_char *path  = n_txt_get( _n_list.txtbox->txt_data, _n_list.txtbox->focus );
		NSString     *nsstr = n_mac_str2nsstring( path );

		if ( n_posix_stat_is_dir( path ) )
		{
			n_mac_finder_call( nsstr );
		} else {
			NSURL *nsurl = [NSURL fileURLWithPath:nsstr];
			[[NSWorkspace sharedWorkspace] openURL:nsurl];
		}
	}

}




- (void)NonnonDragAndDrop_dropped:(NSString*)nsstr
{
//NSLog( @"%@", nsstr );

	nsstr = n_textfield_path( nsstr, YES );

	[_n_path setStringValue:nsstr];


	n_txt_utf8_new( _n_list.txtbox->txt_data );
	[_n_list NonnonTxtboxReset];
	[_n_list display];

}




- (void)awakeFromNib
{

	n_mac_image_window = _window;


	NSFont *font = n_mac_stdfont();


	_n_path.n_folder_only = TRUE;


	_n_search.delegate_option           = N_MAC_TXTBOX_DELEGATE_EDITED | N_MAC_TXTBOX_DELEGATE_F3 | N_MAC_TXTBOX_DELEGATE_SHIFT | N_MAC_TXTBOX_DELEGATE_DELETE;
	_n_search.delegate                  = self;
	_n_search.txtbox->mode              = N_MAC_TXTBOX_MODE_FINDBOX;
	_n_search.txtbox->focus             = 0;
	_n_search.txtbox->option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_NONE;

	[_n_search NonnonTxtboxDataInit];

	[_n_search NonnonTxtboxFontChange:font];

/*
	// [!] : main icons maker
	{
		n_bmp bmp; n_bmp_zero( &bmp );

		n_bmp_ui_search_icon_make( &bmp, 1024, n_bmp_black, n_bmp_white );
n_bmp_ui_search_icon_png_save( &bmp, "/Users/nonnon2/Desktop/icon_main.png" );

		n_bmp_ui_search_icon_make( &bmp, 64, 0, n_bmp_rgb( 128,128,128 ) );
n_bmp_ui_search_icon_png_save( &bmp, "/Users/nonnon2/Desktop/icon_gray.png" );

		n_bmp_free_fast( &bmp );
	}
*/
	[_n_search NonnonTxtboxReset];


	_n_list.delegate_option           = N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT;
	_n_list.delegate                  = self;
	_n_list.txtbox->mode              = N_MAC_TXTBOX_MODE_LISTBOX;
	_n_list.txtbox->option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;
	_n_list.txtbox->listbox_no_edit   = TRUE;
	_n_list.txtbox->scrollbar_patch   = TRUE;

	[_n_list NonnonTxtboxDataInit];

	_n_list.txtbox->listbox_no_selection_onoff = TRUE;

	_n_list.txtbox->path_ellipsis_onoff = TRUE;

	[_n_list NonnonTxtboxFontChange:font];

	[_n_list NonnonTxtboxReset];


	_n_logo.delegate = self;


	// [!] : Xib constraints : misbehaves when size is small
	NSSize nssize = NSMakeSize( 512, 512 );
	[_window setContentMinSize:nssize];


	[self themeChanged:nil];

	[NSDistributedNotificationCenter.defaultCenter
	      addObserver: self
		 selector: @selector( themeChanged: )
		     name: @"AppleInterfaceThemeChangedNotification"
		   object: nil
	];


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

-(void)themeChanged:(NSNotification *) notification
{
//NSLog( @"themeChanged" );

	if ( n_mac_is_darkmode() )
	{
		self.window.backgroundColor = [NSColor windowBackgroundColor];
	} else {
		self.window.backgroundColor = [NSColor whiteColor];
	}

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}




- (IBAction)n_menu_file_name_only:(id)sender {

	NSControlStateValue s = [_n_menu_file_name_only state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_file_name_only setState:NSControlStateValueOn];
		n_nyaagle_is_text_search = FALSE;
	} else {
		[_n_menu_file_name_only setState:NSControlStateValueOff];
		n_nyaagle_is_text_search = TRUE;
	}

	[self NyaagleLogo:n_nyaagle_is_text_search];

}

- (IBAction)n_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"nyaagle" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}


@end
