// Nyaagle for Mac
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static BOOL n_nyaagle_is_text_search = TRUE;




BOOL
n_nyaagle_single_search_text( n_txt *txt_list, n_posix_char *name, n_posix_char *query )
{

	if ( false == n_posix_stat_is_file( name ) ) { return TRUE; }


	n_txt txt; n_txt_zero( &txt );
	if ( n_txt_load_utf8( &txt, name ) ) { return TRUE; }

	if ( txt.readonly ) { return TRUE; }

/*
	// [!] : Xcode : Ctrl+F will fail sometimes
	if ( txt.sy >= 2 )
	{
		n_posix_char *f = n_txt_get( &txt, 0 );
		n_posix_char *t = n_txt_get( &txt, 1 );

		if ( n_string_is_same( f, t ) )
		{
			n_txt_set( txt_list, 0, name );
		}
	}
*/
	if ( n_string_search_simple( txt.stream, query ) )
	{
		n_txt_set( txt_list, 0, name );
	}


	n_txt_free( &txt );


	return FALSE;
}

BOOL
n_nyaagle_single_search_name( n_txt *txt_list, n_posix_char *name, n_posix_char *query )
{
//NSLog( @"%s : %s", name, query );

	if (
		( n_string_search_simple( name, query ) )
		||
		( n_string_wildcard( query, name ) )
	)
	{
		n_txt_set( txt_list, 0, name );

		return TRUE;
	}


	return FALSE;
}

BOOL
n_nyaagle_directory_text( n_txt *txt_list, n_posix_char *name, n_posix_char *query )
{

	if ( FALSE == n_nyaagle_single_search_text( txt_list, name, query ) ) { return FALSE; }

	if ( FALSE == n_posix_stat_is_dir( name ) ) { return TRUE; }


	n_posix_DIR *dp = n_posix_opendir_nodot( name );
	if ( dp == NULL ) { return true; }

	n_posix_loop
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		n_posix_char *abspath = n_string_path_make_new( name, dirent->d_name );

		if ( n_posix_stat_is_dir( abspath ) )
		{
			n_nyaagle_directory_text( txt_list, abspath, query );
		} else {
			n_nyaagle_single_search_text( txt_list, abspath, query );
		}

		n_string_path_free( abspath );

	}

	n_posix_closedir( dp );


	return FALSE;
}

BOOL
n_nyaagle_directory_name( n_txt *txt_list, n_posix_char *name, n_posix_char *query )
{

	if ( FALSE == n_posix_stat_is_dir( name ) ) { return TRUE; }


	n_posix_DIR *dp = n_posix_opendir_nodot( name );
	if ( dp == NULL ) { return true; }

	n_posix_loop
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		n_posix_char *abspath = n_string_path_make_new( name, dirent->d_name );
//NSLog( @"%s", abspath );

		BOOL ret = n_nyaagle_single_search_name( txt_list, abspath, query );

		if ( ( ret == FALSE )&&( n_posix_stat_is_dir( abspath ) ) )
		{
			n_nyaagle_directory_name( txt_list, abspath, query );
		}

		n_string_path_free( abspath );

	}

	n_posix_closedir( dp );


	return FALSE;
}

BOOL
n_nyaagle_directory( n_txt *txt_list, n_posix_char *name, n_posix_char *query )
{
	if ( n_nyaagle_is_text_search )
	{
		return n_nyaagle_directory_text( txt_list, name, query );
	} else {
		return n_nyaagle_directory_name( txt_list, name, query );
	}
}

BOOL
n_nyaagle_directory_narrowed( n_txt *txt_list, n_posix_char *query )
{

	n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );

	n_type_int i = 0;
	n_posix_loop
	{

		if ( n_nyaagle_is_text_search )
		{
			n_nyaagle_single_search_text( &txt, n_txt_get( txt_list, i ), query );
		} else {
			n_nyaagle_single_search_name( &txt, n_txt_get( txt_list, i ), query );
		}

		i++;
		if ( i >= txt_list->sy ) { break; }
	}

	n_txt_free( txt_list );
	n_txt_alias( &txt, txt_list );


	return FALSE;
}
