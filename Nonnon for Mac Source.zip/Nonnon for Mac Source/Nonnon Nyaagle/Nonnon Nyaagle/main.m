//
//  main.m
//  Nyaagle
//
//  Created by のんのん on 2023/02/10.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	@autoreleasepool {
	    // Setup code that might create autoreleased objects goes here.
	}
	return NSApplicationMain(argc, argv);
}
