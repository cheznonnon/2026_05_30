//
//  AppDelegate.m
//  Project Checker
//
//  Created by のんのん on 2022/07/06.
//

#import "AppDelegate.h"


#include "../../nonnon/mac/n_txtbox.c"
#include "../../nonnon/mac/n_textfield.c"

#include "../../nonnon/mac/_mac.c"

#include "../../nonnon/neutral/dir.c"
#include "../../nonnon/neutral/filer.c"
#include "../../nonnon/neutral/txt.c"

#include "./engine.c"




// [!] : only adding white background for File Manager UI

@interface NonnonFileManagerColor : NSView

@end


@implementation NonnonFileManagerColor

- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
	}

	return self;
}

-(void) drawRect:(NSRect) dirtyRect
{
//NSLog( @"!" );

	if ( n_mac_is_darkmode() ) { return; }

	NSRect rect = dirtyRect;
	rect.origin.y = 60;

	[[NSColor whiteColor] setFill];
	NSRectFill( rect );
}

@end




@interface NonnonFileManagerLabel : NSView

@end


@implementation NonnonFileManagerLabel {

	NSString *nsstr;
	NSColor  *color;

	BOOL      contour_onoff;

}

- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
	}

	return self;
}

-(void) drawRect:(NSRect) dirtyRect
{
//NSLog( @"!" );

	NSFont *font = n_mac_stdfont();

	NSMutableParagraphStyle *align = [[NSMutableParagraphStyle alloc] init];
	align.alignment = NSTextAlignmentRight;

	NSMutableDictionary *attr = [NSMutableDictionary dictionary];

	[attr setObject:font  forKey:NSFontAttributeName           ];
	[attr setObject:color forKey:NSForegroundColorAttributeName];
	[attr setObject:align forKey:NSParagraphStyleAttributeName ];


	if (
		( contour_onoff )
		&&
		( n_mac_is_darkmode() )
	)
	{
		NSMutableDictionary *attr_center = [NSMutableDictionary dictionary];

		NSColor *white = [NSColor controlTextColor];

		[attr_center setObject:font  forKey:NSFontAttributeName           ];
		[attr_center setObject:white forKey:NSForegroundColorAttributeName];
		[attr_center setObject:align forKey:NSParagraphStyleAttributeName ];


		NSRect rect;

		rect = [super bounds]; rect.origin.x -= 1; rect.origin.y -= 1; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x -= 1; rect.origin.y -= 0; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x -= 1; rect.origin.y += 1; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x -= 0; rect.origin.y -= 1; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x -= 0; rect.origin.y -= 0; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x -= 0; rect.origin.y += 1; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x += 1; rect.origin.y -= 1; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x += 1; rect.origin.y -= 0; [nsstr drawInRect:rect withAttributes:attr];
		rect = [super bounds]; rect.origin.x += 1; rect.origin.y += 1; [nsstr drawInRect:rect withAttributes:attr];

		rect = [super bounds]; rect.origin.x -= 0; rect.origin.y -= 0; [nsstr drawInRect:rect withAttributes:attr_center];
	} else {
		[nsstr drawInRect:[super bounds] withAttributes:attr];
	}

}

-(void) setStringValue:(NSString*)_nsstr {

	nsstr = _nsstr;

}

-(void) setTextColor:(NSColor*)_color {

	color = _color;

}

-(void) setContourOnOff:(BOOL)onoff {

	contour_onoff = onoff;

}

@end




@interface AppDelegate ()

@property (weak) IBOutlet NonnonTxtbox *n_list;

@property (weak) IBOutlet NSButton *n_button_reverse;
@property (weak) IBOutlet NSButton *n_button_go;

@property (weak) IBOutlet NonnonTextField *n_text_fr;
@property (weak) IBOutlet NonnonTextField *n_text_to;

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NSMenuItem *menu;

@property n_txt n_txt;


@property (weak) IBOutlet NSWindow    *n_filemanager_window;
@property (weak) IBOutlet NSImageView *n_filemanager_icon_from;
@property (weak) IBOutlet NSTextField *n_filemanager_label_from;
@property (weak) IBOutlet NonnonFileManagerLabel *n_filemanager_size_from;
@property (weak) IBOutlet NonnonFileManagerLabel *n_filemanager_time_from;
@property (weak) IBOutlet NSImageView *n_filemanager_icon_to;
@property (weak) IBOutlet NSTextField *n_filemanager_label_to;
@property (weak) IBOutlet NonnonFileManagerLabel *n_filemanager_size_to;
@property (weak) IBOutlet NonnonFileManagerLabel *n_filemanager_time_to;
@property (weak) IBOutlet NSButton    *n_filemanager_button_go;

@end




@implementation AppDelegate {

	BOOL finder_onoff;
	BOOL complete_mode_onoff;

	int  click_phase;
	u32  click_msec;

	int  menu_click_phase;
	u32  menu_click_msec;

	BOOL debug_onoff;

	NSString *target_fr;
	NSString *target_to;

	n_type_int focus_target;

}


@synthesize n_txt;


- (instancetype)init
{
	self = [super init];
	if ( self )
	{
		n_txt_zero( &n_txt ); n_txt_new( &n_txt );

		finder_onoff = FALSE;


		click_phase = 0;
		click_msec  = 0;

		menu_click_phase = 0;
		menu_click_msec  = 0;


		debug_onoff = FALSE;
		//debug_onoff = TRUE;

		if ( debug_onoff )
		{
			int i = 0;
			n_posix_loop
			{
				n_posix_char str[ 100 ]; n_posix_snprintf_literal( str, 100, "Test %d", i );
				n_txt_set( &n_txt, i, str );
				i++;
				if ( i >= 20 ) { break; }
			}
		}

	}


	return self;
}


- (void) n_list_txt_set:(n_posix_char*)str
{
	n_txt_free( &n_txt ); n_txt_new( &n_txt );
	n_txt_set( &n_txt, 0, str );

	[_n_list NonnonTxtboxReset];
	[_n_list display];
}


- (IBAction)n_button_reverse_pressed:(id)sender {

	NSString *tmp = [[_n_text_fr stringValue] copy];
	[_n_text_fr setStringValue:[_n_text_to stringValue]];
	[_n_text_to setStringValue:tmp];

}

- (IBAction)n_button_go:(id)sender {

	[self n_list_txt_set:""];


	NSString *f = [_n_text_fr stringValue];
	NSString *t = [_n_text_to stringValue];
//NSLog( @"%@", f );

	if ( ( [f length] == 0 )||( [t length] == 0 ) )
	{
		[self n_list_txt_set:"Please Check"];
		finder_onoff = FALSE;
		return;
	}

	if ( ( [f compare:@"Drop Here"] == 0 )||( [t compare:@"Drop Here"] == 0 ) )
	{
		[self n_list_txt_set:"Please Check (parameters are not set)"];
		finder_onoff = FALSE;
		return;
	}

//NSLog( @"%d", (int) [f compare:t] );
	if ( [f compare:t] == 0 )
	{
		[self n_list_txt_set:"Please Check (same folder)"];
		finder_onoff = FALSE;
		return;
	}


	NSFileManager *fm = [NSFileManager defaultManager];

	BOOL is_dir_f;
	BOOL exists_f = [fm fileExistsAtPath:f isDirectory:&is_dir_f];

	BOOL is_dir_t;
	BOOL exists_t = [fm fileExistsAtPath:t isDirectory:&is_dir_t];

	if ( ( exists_f == FALSE )||( exists_t == FALSE ) )
	{
		[self n_list_txt_set:"Please Check (not exist)"];
		finder_onoff = FALSE;
		return;
	}
	
	if ( is_dir_f != is_dir_t )
	{
		[self n_list_txt_set:"Please Check (not folder)"];
		finder_onoff = FALSE;
		return;
	}
	
	if ( is_dir_f )
	{
//NSLog( @"Folders" );

		n_posix_char *str_f = n_mac_nsstring2str( f );
		n_posix_char *str_t = n_mac_nsstring2str( t );

		n_txt_free( &n_txt ); n_txt_new( &n_txt );
		n_pc_go_folder( _n_list, &n_txt, str_f, str_t, complete_mode_onoff, TRUE );
		n_pc_sort( &n_txt );

		[_n_list NonnonTxtboxReset];
		[_n_list display];

		finder_onoff = TRUE;

		n_string_free( str_f );
		n_string_free( str_t );

//n_txt_save( &txt, "ret.txt" );

	} else {

		BOOL is_same = [fm contentsEqualAtPath:f andPath:t];
//NSLog( @"is_same : %d", is_same );

		if ( is_same )
		{

			[self n_list_txt_set:"Same Binary"];

		} else {

			[self n_list_txt_set:"Different Binary"];


			n_posix_char *str_f = n_mac_nsstring2str( f );
			n_posix_char *str_t = n_mac_nsstring2str( t );

			BOOL ret = FALSE;

			n_type_int diff_line = -1;

			n_txt txt_f; n_txt_zero( &txt_f ); ret |= n_txt_load( &txt_f, str_f );
			n_txt txt_t; n_txt_zero( &txt_t ); ret |= n_txt_load( &txt_t, str_t );

			if ( ret )
			{
//NSLog( @"n_txt_load()" );
				n_txt_free( &txt_f );
				n_txt_free( &txt_t );

				n_string_free( str_f );
				n_string_free( str_t );

				return;
			}

			if (
				( txt_f.newline == N_TXT_NEWLINE_BINARY )
				||
				( txt_t.newline == N_TXT_NEWLINE_BINARY )
			)
			{
//NSLog( @"N_TXT_NEWLINE_BINARY" );
				n_txt_free( &txt_f );
				n_txt_free( &txt_t );

				n_string_free( str_f );
				n_string_free( str_t );

				return;
			}

			n_type_int i = 0;
			n_posix_loop
			{
				if ( ( i >= txt_f.sy )&&( i >= txt_t.sy ) ) { break; }

				if ( i >= txt_f.sy ) { diff_line = i; break; }
				if ( i >= txt_t.sy ) { diff_line = i; break; }

				if ( n_string_is_same( n_txt_get( &txt_f, i ), n_txt_get( &txt_t, i ) ) )
				{
					//
				} else {
					diff_line = i;
					break;
				}

				i++;
			}


			if ( diff_line != -1 )
			{
				n_posix_char str_line[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_line, 1 + diff_line );

				n_posix_char str[ 100 ];
				n_posix_snprintf_literal( str, 100, "Line #%s", str_line );
//NSLog( @"%s", str );

				n_txt_add( &n_txt, 1, str );

				[_n_list display];
			}

			n_txt_free( &txt_f );
			n_txt_free( &txt_t );

			n_string_free( str_f );
			n_string_free( str_t );

		}

		finder_onoff = FALSE;
	}

}




- (void) NonnonProjectCheckerFilemanager:(void*) p from:(n_posix_char*)f to:(n_posix_char*)t
{

	if (
		( FALSE == n_posix_stat_is_exist( f ) )
		||
		( FALSE == n_posix_stat_is_exist( t ) )
	)
	{
		n_mac_window_dialog_ok( "Not Exist" );

		return;
	}


	target_fr = n_mac_str2nsstring( f );
	target_to = n_mac_str2nsstring( t );


	[_n_filemanager_icon_from setImage:[[NSWorkspace sharedWorkspace] iconForFile:target_fr]];
	[_n_filemanager_icon_to   setImage:[[NSWorkspace sharedWorkspace] iconForFile:target_to]];


	[_n_filemanager_label_from setStringValue:target_fr];
	[_n_filemanager_label_to   setStringValue:target_to];


	NSFileManager *fm = [NSFileManager defaultManager];
	NSError       *er = nil;

	NSDictionary *attr_f = [fm attributesOfItemAtPath:target_fr error:&er];
	NSDictionary *attr_t = [fm attributesOfItemAtPath:target_to error:&er];

	n_type_int size_f = [attr_f fileSize];//n_posix_stat_size( f );
	n_type_int size_t = [attr_t fileSize];//n_posix_stat_size( t );
//NSLog( @"From : %lld", size_f );
//NSLog( @"To   : %lld", size_t );

	[_n_filemanager_size_from setTextColor:[NSColor controlTextColor]];
	[_n_filemanager_size_to   setTextColor:[NSColor controlTextColor]];

	[_n_filemanager_size_from setContourOnOff:FALSE];
	[_n_filemanager_size_to   setContourOnOff:FALSE];

	if ( size_f > size_t )
	{
		[_n_filemanager_size_from setTextColor:[NSColor controlAccentColor]];
		[_n_filemanager_size_from setContourOnOff:TRUE];

		[_n_filemanager_size_from setStringValue:[NSString stringWithFormat:@"%lld Byte (Larger)" , size_f]];
		[_n_filemanager_size_to   setStringValue:[NSString stringWithFormat:@"%lld Byte (Smaller)", size_t]];
	} else
	if ( size_f < size_t )
	{
		[_n_filemanager_size_to   setTextColor:[NSColor controlAccentColor]];
		[_n_filemanager_size_to   setContourOnOff:TRUE];

		[_n_filemanager_size_from setStringValue:[NSString stringWithFormat:@"%lld Byte (Smaller)", size_f]];
		[_n_filemanager_size_to   setStringValue:[NSString stringWithFormat:@"%lld Byte (Larger)" , size_t]];
	} else {
		[_n_filemanager_size_from setStringValue:[NSString stringWithFormat:@"%lld Byte", size_f]];
		[_n_filemanager_size_to   setStringValue:[NSString stringWithFormat:@"%lld Byte" , size_t]];
	}

	[_n_filemanager_size_from display];
	[_n_filemanager_size_to   display];


	//n_posix_char mtime_f[ 100 ]; n_time_string_mtime( f, mtime_f, 100 );
	//n_posix_char mtime_t[ 100 ]; n_time_string_mtime( t, mtime_t, 100 );

	//[_n_filemanager_time_from setStringValue:n_mac_str2nsstring( mtime_f )];
	//[_n_filemanager_time_to   setStringValue:n_mac_str2nsstring( mtime_t )];

	NSURL *URL_f = [NSURL fileURLWithPath:target_fr];
	NSURL *URL_t = [NSURL fileURLWithPath:target_to];

	NSError *error;

	NSDate *date_f; [URL_f getResourceValue:&date_f forKey:NSURLContentModificationDateKey error:&error];
	NSDate *date_t; [URL_t getResourceValue:&date_t forKey:NSURLContentModificationDateKey error:&error];

	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];

	formatter.dateStyle = NSDateFormatterMediumStyle;
	formatter.timeStyle = NSDateFormatterMediumStyle;

	[_n_filemanager_time_from setTextColor:[NSColor controlTextColor]];
	[_n_filemanager_time_to   setTextColor:[NSColor controlTextColor]];

	NSString *date_nsstr_f = [formatter stringFromDate:date_f];
	NSString *date_nsstr_t = [formatter stringFromDate:date_t];

	[_n_filemanager_time_from setContourOnOff:FALSE];
	[_n_filemanager_time_to   setContourOnOff:FALSE];

	if ( [date_f laterDate:date_t] == date_f )
	{
		[_n_filemanager_time_from setTextColor:[NSColor controlAccentColor]];
		[_n_filemanager_time_from setContourOnOff:TRUE];

		date_nsstr_f = [date_nsstr_f stringByAppendingString:@" (Newer)"];
		date_nsstr_t = [date_nsstr_t stringByAppendingString:@" (Older)"];
	} else
	if ( [date_t laterDate:date_f] == date_t )
	{
		[_n_filemanager_time_to   setTextColor:[NSColor controlAccentColor]];
		[_n_filemanager_time_to   setContourOnOff:TRUE];

		date_nsstr_f = [date_nsstr_f stringByAppendingString:@" (Older)"];
		date_nsstr_t = [date_nsstr_t stringByAppendingString:@" (Newer)"];
	}

	[_n_filemanager_time_from setStringValue:date_nsstr_f];
	[_n_filemanager_time_to   setStringValue:date_nsstr_t];

	[_n_filemanager_time_from display];
	[_n_filemanager_time_to   display];


	[NSApp runModalForWindow:_n_filemanager_window];

}

- (IBAction)n_filemanager_button_method:(NSButton *)sender {

	[NSApp stopModal];

	n_posix_char *f = n_mac_nsstring2str( target_fr );
	n_posix_char *t = n_mac_nsstring2str( target_to );

	if ( FALSE == n_filer_merge( f, t ) )
	{
		n_txt_del( &n_txt, focus_target );
		[_n_list display];
	}

	n_string_free( f );
	n_string_free( t );

	[_n_filemanager_window close];

}




- (void)rightMouseDown:(NSEvent *)theEvent
{

	[_n_list mouseDown:theEvent];

}

- (void)rightMouseUp:(NSEvent *)theEvent
{

	BOOL double_click_onoff = n_mac_doubleclick_detect( &menu_click_phase, &menu_click_msec );
	//BOOL double_click_onoff = ( ( [theEvent clickCount] % 3 ) == 2 );

	if ( double_click_onoff )
	{
//NSLog( @"double clicked" ); return;

		if ( finder_onoff == FALSE ) { return; }


		focus_target = _n_list.txtbox->focus;

		n_posix_char *item = n_string_carboncopy( n_txt_get( &n_txt, focus_target ) );
		if ( 4 > n_posix_strlen( item ) ) { return; }


		NSString *nsstr_f = [_n_text_fr stringValue];
		NSString *nsstr_t = [_n_text_to stringValue];
	
		n_posix_char *f = n_mac_nsstring2str( nsstr_f );
		n_posix_char *t = n_mac_nsstring2str( nsstr_t );

 
		// [!] : don't use n_string_path_name()
		//
		//	this will be relative path

		n_posix_char *name = n_string_path_carboncopy( item );

		n_string_copy( &item[ 4 ], item );
		n_string_copy( &item[ n_posix_strlen( t ) ], name );

		n_string_free( item );


		n_posix_char *f2 = n_string_path_cat( f, name, NULL );
		n_posix_char *t2 = n_string_path_cat( t, name, NULL );

		n_string_path_free( f ); f = f2;
		n_string_path_free( t ); t = t2;

		if (
			( FALSE == n_posix_stat_is_exist( f ) )
			||
			( n_posix_stat_is_dir( f ) )
		)
		{
			n_posix_char *upper = n_string_path_upperfolder_new( f );
			n_string_path_free( f ); f = upper;
		}

		if (
			( FALSE == n_posix_stat_is_exist( t ) )
			||
			( n_posix_stat_is_dir( t ) )
		)
		{
			n_posix_char *upper = n_string_path_upperfolder_new( t );
			n_string_path_free( t ); t = upper;
		}

		n_mac_finder_call( n_mac_str2nsstring( f ) );
		n_mac_finder_call( n_mac_str2nsstring( t ) );

	}

	if ( debug_onoff )
	{

		if ( double_click_onoff )
		{
//NSLog( @"Double-Clicked" );
			n_txt_del( &n_txt, focus_target );
			[_n_list display];
		} else {
//NSLog( @"Single-Clicked" );
		}

		return;
	}

}




- (void)mouseUp:(NSEvent *)theEvent
{
//return;

	BOOL double_click_onoff = n_mac_doubleclick_detect( &click_phase, &click_msec );
	//BOOL double_click_onoff = ( ( [theEvent clickCount] % 3 ) == 2 );

	if ( double_click_onoff )
	{
//NSLog( @"double clicked" );


		if ( finder_onoff == FALSE ) { return; }


		focus_target = _n_list.txtbox->focus;
		if ( focus_target == -1 ) { return; }

		[_n_list NonnonTxtboxCaretReset];


		n_posix_char *item = n_string_carboncopy( n_txt_get( &n_txt, focus_target ) );
		if ( 4 > n_posix_strlen( item ) ) { return; }


		[[NSCursor operationNotAllowedCursor] set];


		NSString *nsstr_f = [_n_text_fr stringValue];
		NSString *nsstr_t = [_n_text_to stringValue];
	
		n_posix_char *f = n_mac_nsstring2str( nsstr_f );
		n_posix_char *t = n_mac_nsstring2str( nsstr_t );

 
		// [!] : don't use n_string_path_name()
		//
		//	this will be relative path

		n_posix_char *name = n_string_path_carboncopy( item );

		int mode = 0;
		if ( item[ 0 ] == '!' ) { mode = 1; }
		if ( item[ 0 ] == '?' ) { mode = 1; }
		if ( item[ 0 ] == '+' ) { mode = 2; }

		n_string_copy( &item[ 4 ], item );
		n_string_copy( &item[ n_posix_strlen( t ) ], name );

		n_string_free( item );


		n_posix_char *f2 = n_string_path_cat( f, name, NULL );
		n_posix_char *t2 = n_string_path_cat( t, name, NULL );

		n_string_path_free( f ); f = f2;
		n_string_path_free( t ); t = t2;


//NSLog( @"Mode %d", mode );
		if ( mode == 1 )
		{
/*
			if ( FALSE == n_filer_merge( f, t ) )
			{
				n_txt_del( &n_txt, focus_target );
				[_n_list display];
			}
*/
			[self NonnonProjectCheckerFilemanager:NULL from:f to:t];
		} else
		if ( mode == 2 )
		{
			NSURL *url = [NSURL fileURLWithPath:n_mac_str2nsstring( t )];

			BOOL ret = [[NSFileManager defaultManager]
				 trashItemAtURL:url
			       resultingItemURL:nil
				          error:nil
			];

			if ( ret == YES )
			{
				n_txt_del( &n_txt, focus_target );
				[_n_list display];
			}
		}

		n_string_path_free( f );
		n_string_path_free( t );


		[[NSCursor arrowCursor] set];

	}

}


- (IBAction)n_complete_mode_onoff:(id)sender {

	NSControlStateValue s = [_menu state];
	if ( s == NSControlStateValueOff )
	{
		[_menu setState:NSControlStateValueOn];
		complete_mode_onoff = TRUE;
	} else {
		[_menu setState:NSControlStateValueOff];
		complete_mode_onoff = FALSE;
	}

}


- (void)awakeFromNib
{

	n_mac_image_window = _window;

	_n_list.delegate_option           = N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT | N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_RIGHT | N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT;
	_n_list.delegate                  = self;
	_n_list.txtbox->mode              = N_MAC_TXTBOX_MODE_LISTBOX;
	_n_list.txtbox->txt_data          = &n_txt;
	_n_list.txtbox->option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;

	_n_list.txtbox->listbox_no_selection_onoff = TRUE;
	_n_list.txtbox->listbox_no_edit            = TRUE;

	_n_list.txtbox->scrollbar_patch = TRUE;

	_n_list.txtbox->path_ellipsis_onoff  = TRUE;
	_n_list.txtbox->path_ellipsis_offset = 4;

	NSFont *font = n_mac_stdfont();
	[_n_list NonnonTxtboxFontChange:font];

	[_n_list NonnonTxtboxReset];


	// [!] : macOS 12 Monterey needs this
	[_window setFrameAutosaveName:@"Nonnon.ProjectChecker"];

	// [!] : Xib constraints : misbehaves when size is small
	NSSize nssize = NSMakeSize( 480, 360 );
	[_window setContentMinSize:nssize];


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	} else
	if ( window == _n_filemanager_window )
	{
		[NSApp stopModal];
	}

}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}




- (IBAction)n_pc_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"project checker" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}


@end
