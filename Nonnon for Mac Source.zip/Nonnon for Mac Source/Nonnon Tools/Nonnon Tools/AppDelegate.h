//
//  AppDelegate.h
//  Nonnon Tools
//
//  Created by のんのん on 2022/11/07.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

