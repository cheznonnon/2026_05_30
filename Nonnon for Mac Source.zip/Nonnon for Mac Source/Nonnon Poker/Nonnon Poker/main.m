//
//  main.m
//  Nonnon Poker
//
//  Created by のんのん２ on 2024/12/18.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	@autoreleasepool {
	    // Setup code that might create autoreleased objects goes here.
	}
	return NSApplicationMain(argc, argv);
}
