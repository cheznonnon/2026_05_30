// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonTxtbox
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonTxtbox"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_txtbox NonnonTxtboxRedraw];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_TXTBOX
#define _H_NONNON_MAC_NONNON_TXTBOX




#import <Cocoa/Cocoa.h>



#include "_mac.c"
#include "draw.c"
#include "image.c"
#include "window.c"


#include "../neutral/bmp/ui/rectframe.c"
#include "../neutral/bmp/ui/roundframe.c"
#include "../neutral/bmp/ui/search_icon.c"
#include "../neutral/bmp/ui/timer.c"

#include "../neutral/txt.c"

#include "../bridge/gdi.c"


#include "n_txtbox/00_codec.c"
#include "n_txtbox/01_character.c"
#include "n_txtbox/02_caret.c"
#include "n_txtbox/03_selection.c"
#include "n_txtbox/04_edit.c"
#include "n_txtbox/05_date.c"
#include "n_txtbox/06_undo.c"




#define N_TXTBOX_IME_ENABLE




#define N_MAC_TXTBOX_MODE_EDITBOX ( 0 )
#define N_MAC_TXTBOX_MODE_LISTBOX ( 1 )
#define N_MAC_TXTBOX_MODE_FINDBOX ( 2 )
#define N_MAC_TXTBOX_MODE_ONELINE ( 3 )


#define N_MAC_TXTBOX_CARET_SIZE   ( 2 )


#define N_MAC_TXTBOX_DRAW_LINENUMBER_NONE            ( 0 << 0 )
#define N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX  ( 1 << 0 )
#define N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX ( 1 << 1 )


#define N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT  ( 1 <<  0 )
#define N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT    ( 1 <<  1 )
#define N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_RIGHT ( 1 <<  2 )
#define N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT   ( 1 <<  3 )
#define N_MAC_TXTBOX_DELEGATE_LISTBOX_EDITED  ( 1 <<  4 )
#define N_MAC_TXTBOX_DELEGATE_LISTBOX_MOVED   ( 1 <<  5 )
#define N_MAC_TXTBOX_DELEGATE_EDITED          ( 1 <<  6 )
#define N_MAC_TXTBOX_DELEGATE_FIND            ( 1 <<  7 )
#define N_MAC_TXTBOX_DELEGATE_SWAP            ( 1 <<  8 )
#define N_MAC_TXTBOX_DELEGATE_F3              ( 1 <<  9 )
#define N_MAC_TXTBOX_DELEGATE_DELETE          ( 1 << 10 )
#define N_MAC_TXTBOX_DELEGATE_SHIFT           ( 1 << 11 )
#define N_MAC_TXTBOX_DELEGATE_UNDO            ( 1 << 12 )
#define N_MAC_TXTBOX_DELEGATE_ALL             0xffff




typedef struct {

	n_type_real unit_pos , pixel_pos;
	n_type_real unit_max , pixel_max;
	n_type_real unit_page, pixel_page;
	n_type_real unit_step, pixel_step;
	n_type_real pixel_thumb;
	n_type_real pixel_minim;
	n_type_real pixel_shaft;

} n_txtbox_scroll;


typedef struct {

	// Public

	n_type_int  focus;

	int         mode;

	NSString   *path;

	n_txt      *txt_data;
	n_txt      *txt_deco;

	BOOL        direct_click_onoff;
	int         option_linenumber;
	BOOL        edited;

	BOOL        is_enter_pressed;

	BOOL        border_separator_only;
	BOOL        scrollbar_patch;

	BOOL        listbox_no_selection_onoff;
	BOOL        listbox_edit_onoff;
	BOOL        listbox_no_edit;

	BOOL        path_ellipsis_onoff;
	n_type_int  path_ellipsis_offset;

	BOOL       *search_marker;
	n_type_int  search_marker_count;


	// Private

	CGFloat     offset, offset_x, offset_y;
	CGFloat     margin;
	CGFloat     padding;

	NSFont     *font;
	CGSize      font_size;

	CGPoint     pt_cur, pt_prv;
	CGPoint     pt_grab_n_drag;

	n_type_int  redraw_fy;
	n_type_int  redraw_ty;

	BOOL        is_grayed;
	BOOL        is_darkmode;
	BOOL        is_key_input;

	BOOL        grab_n_drag_onoff;

	BOOL        shift_selection_is_tail;

	n_undo      undo;

	BOOL        drag_timer_queue;

	n_txtbox_scroll scr;
	BOOL            scrollbar_used;
	n_bmp_fade      scrollbar_fade;
	BOOL            scrollbar_fade_hovered_onoff;
	BOOL            scrollbar_fade_captured_onoff;
	NSRect          scrollbar_thumb_rect;
	BOOL            scrollbar_thumb_is_captured;
	BOOL            scrollbar_thumb_is_hovered;
	CGFloat         scrollbar_thumb_offset;
	NSRect          scrollbar_shaft_rect;
	BOOL            scrollbar_shaft_is_hovered;

	NSFont     *linenumber_font;
	CGSize      linenumber_size;
	CGSize      linenumber_single;
	u32         linenumber_color_back;
	u32         linenumber_color_text;

	CGPoint     caret_pt;
	n_caret     caret_fr;
	n_caret     caret_to;
	BOOL        caret_blink_onoff;
	BOOL        caret_blink_force_onoff;
	n_bmp_fade  caret_blink_fade;
	u32         caret_blink_interval;
	CGFloat     caret_centered_offset;

	NSRect      find_icon_rect;
	BOOL        find_icon_is_pressed;
	BOOL        find_icon_focus_prev;
	BOOL        find_icon_press_prev;
	n_bmp       find_icon;
	NSImage    *find_icon_cache_nsimage;
	n_bmp_fade  find_icon_fade;

	NSRect      delete_circle_rect;
	BOOL        delete_circle_is_pressed;
	BOOL        delete_circle_is_hovered;
	n_bmp_fade  delete_circle_fade_hovered;
	int         delete_circle_fade_pressed_phase;
	n_bmp_fade  delete_circle_fade_pressed;

	n_type_int  listbox_edit_index;

	BOOL        smooth_wheel_is_mos;
	BOOL        smooth_wheel_onoff;
	CGFloat     smooth_wheel_delta;
	BOOL        smooth_wheel_mutex;

	BOOL        smooth_wheel_animation_onoff;
	u32         smooth_wheel_animation_msec;
	int         smooth_wheel_animation_count;
	u32         smooth_wheel_animation_timer;

	NSColor    *nscolor_white;
	NSColor    *nscolor_black;
	NSColor    *nscolor_text;
	NSColor    *nscolor_back;
	NSColor    *nscolor_text_highlight;
	NSColor    *nscolor_crlf;
	NSColor    *nscolor_accent;
	NSColor    *nscolor_nofocus;
	NSColor    *nscolor_ime_main;
	NSColor    *nscolor_ime_rest;
	NSColor    *nscolor_stripe;
	NSColor    *nscolor_frame;
	NSColor    *nscolor_text_normal;

	NSMutableDictionary *attr;
	NSMutableDictionary *attr_crlf;
	NSMutableDictionary *attr_ime;

	NSString *crlf_nsstring;
	NSSize    crlf_pixel_size;
	CGFloat   crlf_ox;
	CGFloat   crlf_oy;

#ifdef N_TXTBOX_IME_ENABLE

	NSTextInputContext *ime;
	n_caret             ime_caret_fr;
	n_caret             ime_caret_to;
	NSString           *ime_nsstr;
	BOOL                ime_onoff;
	BOOL                ime_freed;
	NSRange             ime_focus;
	BOOL                ime_delay;
	BOOL                ime_is_first;
	n_type_int          ime_caret_offset;
	NSRect              ime_caret_rect;

	NSRect              underline_rect;
	CGFloat             underline_fx;
	CGFloat             underline_tx;

#endif

} n_txtbox;




#define n_txtbox_round( r ) trunc( r )




@protocol NonnonTxtbox_delegate

- (void) NonnonTxtbox_delegate_dropped;

@optional

- (void) NonnonTxtbox_delegate_listbox_edited:(n_type_int)index;
- (void) NonnonTxtbox_delegate_listbox_rename:(n_type_int)index;

- (void) NonnonTxtbox_delegate_edited:(id)txtbox onoff:(BOOL)onoff;
- (void) NonnonTxtbox_delegate_find  :(id)txtbox;
- (void) NonnonTxtbox_delegate_swap  :(id)txtbox is_up:(BOOL)is_up;
- (void) NonnonTxtbox_delegate_F3    :(id)txtbox is_left:(BOOL)is_left;
- (void) NonnonTxtbox_delegate_delete:(id)txtbox;
- (void) NonnonTxtbox_delegate_shift :(NSEvent*) event;
- (void) NonnonTxtbox_delegate_undo  :(id)txtbox;

@end




#ifdef N_TXTBOX_IME_ENABLE
@interface NonnonTxtbox : NSView <NSTextInputClient>
#else
@interface NonnonTxtbox : NSView
#endif

@property (nonatomic,assign) id delegate;
@property int                   delegate_option;

@end




@interface NonnonTxtbox ()

@property n_txtbox  txtbox_instance;
@property n_txtbox *txtbox;

@end




static NonnonTxtbox *n_txtbox_first_responder = nil;




@implementation NonnonTxtbox {

}


@synthesize delegate_option;
@synthesize delegate;


@synthesize txtbox;




- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{

		n_bmp_safemode = FALSE;

		n_bmp_transparent_onoff_default = FALSE;


		txtbox = &_txtbox_instance;


		{
			NSArray      *paths   = NSSearchPathForDirectoriesInDomains( NSDesktopDirectory, NSUserDomainMask, YES );
			NSString     *desktop = [paths objectAtIndex:0];
			n_posix_char  tmpname[ 100 ]; n_string_path_tmpname( tmpname );

			txtbox->path = [NSString stringWithFormat:@"%@/%s.txt", desktop, tmpname];
//NSLog( @"%@", path );
		}


		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];

/*
		// [x] : gray-out at lost focus : un-implementable : system should do

		[[NSNotificationCenter defaultCenter]
			addObserver:self
			   selector:@selector( applicationWillBecomeActive: )
			       name:NSApplicationDidBecomeActiveNotification
			     object:nil
		];

		[[NSNotificationCenter defaultCenter]
			addObserver:self
			   selector:@selector( applicationWillResignActive: )
			       name:NSApplicationDidResignActiveNotification
			     object:nil
		];
*/
/*
		NSTrackingArea* trackingArea = [[NSTrackingArea alloc]
			initWithRect:[self bounds]
			     options:NSTrackingMouseEnteredAndExited | NSTrackingActiveAlways
			       owner:self
			    userInfo:nil
		];
		[self addTrackingArea:trackingArea];
*/

		// [!] : accent color
		[[NSDistributedNotificationCenter defaultCenter]
			addObserver: self
			   selector: @selector( accentColorChanged: )
			       name: @"AppleColorPreferencesChangedNotification"
			     object: nil
		];

		// [!] : dark mode
		[[NSDistributedNotificationCenter defaultCenter]
			addObserver: self
			   selector: @selector( darkModeChanged: )
			       name: @"AppleInterfaceThemeChangedNotification"
			     object: nil
		];


		self.wantsLayer = YES;


		[self NonnonTxtboxFontDefault];


		txtbox->offset = 6;
		txtbox->margin = 3;

		txtbox->offset_x = txtbox->offset_y = txtbox->offset;

		[self NonnonTxtboxReset];

		txtbox->is_darkmode = n_mac_is_darkmode();
		[self NonnonTxtBoxColorScheme];

		n_bmp_fade_init( &txtbox->scrollbar_fade, n_bmp_black );

		n_undo_zero( &txtbox->undo ); n_txt_zero( &txtbox->undo.txt ); n_txt_utf8_new( &txtbox->undo.txt );

		txtbox->edited = FALSE;

		txtbox->smooth_wheel_is_mos = FALSE;
		txtbox->smooth_wheel_onoff  = FALSE;

		n_mac_timer_init( self, @selector( _NonnonTxtboxScrollbarTimer    ),  33 );
		n_mac_timer_init( self, @selector( _NonnonTxtboxCaretBlinkTimer   ),  66 );
		n_mac_timer_init( self, @selector( _NonnonTxtboxDeleteCircleTimer ),  33 );
		n_mac_timer_init( self, @selector( _NonnonTxtboxDragTimer         ),  33 );
		n_mac_timer_init( self, @selector( _NonnonTxtboxSmoothWheelTimer  ),   1 );
//n_mac_timer_init( self, @selector( _NonnonTxtboxTestTimer         ),  33 );

	}
	
	return self;
}




- (void) accentColorChanged:(NSNotification *)notification
{
//NSLog( @"accentColorChanged" );

	// [x] : Sonoma : buggy : old value is set

	n_mac_timer_init_once( self, @selector( n_timer_method_color ), 200 );

}

- (void) darkModeChanged:(NSNotification *)notification
{
//NSLog( @"darkModeChanged" );

	// [x] : Sonoma : buggy : old value is set

	n_mac_timer_init_once( self, @selector( n_timer_method_color ), 200 );

}

- (void) n_timer_method_color
{
//NSLog( @"n_timer_method_color" );

	txtbox->is_darkmode = n_mac_is_darkmode();

	[self NonnonTxtBoxColorScheme];

	[self NonnonTxtboxRedraw];

}

- (void) NonnonTxtBoxColorScheme
{

	if ( txtbox->is_darkmode )
	{
		txtbox->nscolor_text = n_mac_nscolor_argb( 255,222,222,222 );
	} else {
		txtbox->nscolor_text = [NSColor textColor];
	}

	txtbox->nscolor_back = [NSColor textBackgroundColor];

	if ( txtbox->is_darkmode )
	{
		txtbox->nscolor_back = n_mac_nscolor_blend( txtbox->nscolor_back, txtbox->nscolor_text, 0.20 );
	}

	if ( txtbox->is_grayed )
	{
		txtbox->nscolor_text = n_mac_nscolor_blend( txtbox->nscolor_back, txtbox->nscolor_text, 0.55 );
		txtbox->nscolor_back = n_mac_nscolor_blend( txtbox->nscolor_back, txtbox->nscolor_text, 0.05 );
	}

	txtbox->nscolor_text_normal = txtbox->nscolor_text;

	if ( txtbox->is_darkmode )
	{
		txtbox->nscolor_text_highlight = txtbox->nscolor_text;
	} else {
		txtbox->nscolor_text_highlight = txtbox->nscolor_back;
	}

	txtbox->nscolor_accent = [NSColor controlAccentColor];

	if ( txtbox->is_darkmode )
	{
		txtbox->nscolor_nofocus = n_mac_nscolor_argb( 255,100,100,100 );
	} else {
		txtbox->nscolor_nofocus = n_mac_nscolor_argb( 255,200,200,200 );
	}

	txtbox->nscolor_nofocus = n_mac_nscolor_blend( txtbox->nscolor_nofocus, txtbox->nscolor_accent, 0.25 );


#ifdef N_TXTBOX_IME_ENABLE

	txtbox->nscolor_ime_main = txtbox->nscolor_accent;

	if ( txtbox->is_darkmode )
	{
		txtbox->nscolor_ime_rest = [NSColor whiteColor];
	} else {
		txtbox->nscolor_ime_rest = n_mac_nscolor_argb( 255,200,200,200 );
	}

#endif

}




- (void) NonnonTxtboxEditedSet:(BOOL) onoff
{
	txtbox->edited = onoff;
}

- (void) NonnonTxtboxEditedNotifyForced:(BOOL) onoff
{

	txtbox->edited = onoff;

	if ( delegate_option & N_MAC_TXTBOX_DELEGATE_EDITED )
	{
		[self.delegate NonnonTxtbox_delegate_edited:self onoff:txtbox->edited];
	}

}

- (void) NonnonTxtboxEditedNotify:(BOOL) onoff
{

	if ( txtbox->edited == onoff ) { return; }

	[self NonnonTxtboxEditedNotifyForced:onoff];

}

- (void) NonnonTxtboxRedraw
{

	// [x] : setNeedsDisplay is heavier by approx. 1%

	[self display];
	//[self setNeedsDisplay:YES];

}

- (void) NonnonTxtboxRedrawPartial
{
//return;

	// [!] : efficient mode : unimplementable : macOS is too buggy

	[self display];

/*
	redraw_fy = txtbox->focus;
	redraw_ty = redraw_fy + 1;

	n_type_int i = scroll;

	NSRect _rect_main = NSMakeRect( padding - margin, offset_y - caret_centered_offset, self.frame.size.width - ( offset_x * 2 ), font_size.height );

	_rect_main.origin.y -= font_size.height * i;
	_rect_main.origin.y += font_size.height * redraw_fy;

	[self displayRect:_rect_main];
*/
}




- (void) NonnonTxtboxDataInit
{

	txtbox->txt_data = n_memory_new( sizeof( n_txt ) );

	n_txt_zero( txtbox->txt_data );

	n_txt_utf8_new( txtbox->txt_data );

}




- (void) NonnonTxtboxSearchMarkerReset:(BOOL)redraw
{
//NSLog( @"%x", (int) txtbox->search_marker );

	if ( txtbox->search_marker != NULL )
	{
		n_memory_free( txtbox->search_marker );

		txtbox->search_marker       = NULL;
		txtbox->search_marker_count = 0;

		if ( redraw ) { [self NonnonTxtboxRedraw]; }
	}

}




- (void) NonnonTxtboxCaretReset
{

	if (
		( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
		&&
		( txtbox->listbox_no_selection_onoff )
	)
	{
		txtbox->focus = -1;
	} else {
		txtbox->focus = 0;
	}

	txtbox->caret_fr = NonnonMakeCaret( 0,0,0,0 );
	txtbox->caret_to = NonnonMakeCaret( 0,0,0,0 );

#ifdef N_TXTBOX_IME_ENABLE

	// [!] : Sonoma : popup indicator is implemented : this is used in the first time

	txtbox->ime_caret_fr = txtbox->caret_fr;
	txtbox->ime_caret_to = txtbox->caret_to;

#endif

}

- (void) NonnonTxtboxCaretCalculate
{

	// [!] : caret on the current screen

	n_caret pt = txtbox->caret_fr;

	if ( txtbox->caret_fr.cch.y == txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_fr.cch.y == txtbox->focus )
		{
			if ( txtbox->caret_fr.pxl.x == txtbox->caret_to.pxl.x )
			{
//NSLog( @"==" );
				//
			} else
			if ( txtbox->caret_fr.pxl.x < txtbox->caret_to.pxl.x )
			{
//NSLog( @"< : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = txtbox->caret_to;
			} else {
//NSLog( @"> : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = txtbox->caret_to;
			}
		}
	} else
	if ( txtbox->caret_fr.cch.y < txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_to.cch.y == txtbox->focus ) { pt = txtbox->caret_to; }
	} else
	if ( txtbox->caret_fr.cch.y > txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_to.cch.y == txtbox->focus ) { pt = txtbox->caret_to; }
	}

	txtbox->caret_pt.x = txtbox->padding + pt.pxl.x - 1;
	txtbox->caret_pt.y = txtbox->offset_y + ( ( pt.cch.y - n_txtbox_round( txtbox->scr.unit_pos ) ) * txtbox->font_size.height );


#ifdef N_TXTBOX_IME_ENABLE

	// [!] : Sonoma : popup indicator is implemented : this is used in the first time

	txtbox->ime_caret_fr = txtbox->caret_fr;
	txtbox->ime_caret_to = txtbox->caret_to;

#endif


	return;
}




- (void) NonnonTxtboxFontChangeAttr
{

	txtbox->attr = [NSMutableDictionary dictionary];
	[txtbox->attr setObject:txtbox->font forKey:NSFontAttributeName];

#ifdef N_TXTBOX_IME_ENABLE

	txtbox->attr_ime = [NSMutableDictionary dictionary];
	[txtbox->attr_ime setObject:txtbox->font forKey:NSFontAttributeName];

#endif
}

- (void) NonnonTxtboxFontChange:(NSFont*)font_new
{

	txtbox->font = font_new;
	[self NonnonTxtboxFontChangeAttr];


	txtbox->font_size = n_mac_image_text_pixelsize( @" ", txtbox->font );

	txtbox->linenumber_font   = [NSFont userFixedPitchFontOfSize:txtbox->font.pointSize];
	txtbox->linenumber_size   = n_mac_image_text_pixelsize( @"000000", txtbox->linenumber_font );
	txtbox->linenumber_single = n_mac_image_text_pixelsize( @"0"     , txtbox->linenumber_font );

}

- (void) NonnonTxtboxFontDefault
{

	// [x] : Catalina : monospacedSystemFontOfSize : CJK unified idiogram
	//
	//	non-japanese glyphs will be used
	//
	//	Monterey : it seems to be fixed
	//
	//	Font Panel : named font is needed

	//txtbox->font      = [NSFont monospacedSystemFontOfSize:15 weight:NSFontWeightRegular];
	//txtbox->font      = [NSFont systemFontOfSize:15 weight:NSFontWeightRegular];

	//n_mac_txtbox_character_monospace_onoff = TRUE;
	//txtbox->font      = [NSFont fontWithName:@"Hiragino Maru Gothic Pro" size:14];

	//txtbox->font      = [NSFont userFixedPitchFontOfSize:15];
	txtbox->font      = [NSFont fontWithName:@"Menlo" size:15];

	[self NonnonTxtboxFontChange:txtbox->font];

}




- (void) NonnonTxtboxReset
{

	 if ( txtbox->border_separator_only ) { txtbox->offset_x = 4; }


	if ( self.txtbox->option_linenumber == N_MAC_TXTBOX_DRAW_LINENUMBER_NONE )
	{
		txtbox->padding = txtbox->offset_x;
	} else {
		txtbox->padding = txtbox->offset_x + txtbox->linenumber_size.width + txtbox->margin;
	}


	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		n_bmp_ui_search_icon_make( &txtbox->find_icon, 1024, 0, n_bmp_black );

		txtbox->padding += self.frame.size.height;
	}


	txtbox->scr.unit_pos = 0;

	if ( txtbox->listbox_no_selection_onoff )
	{
		txtbox->focus = -1;
	} else {
		txtbox->focus = 0;
	}

	txtbox->scrollbar_thumb_rect = NSMakeRect( 0,0,0,0 );
	txtbox->scrollbar_shaft_rect = NSMakeRect( 0,0,0,0 );


	n_bmp_fade_init( &txtbox->scrollbar_fade, n_bmp_black );

	txtbox->scrollbar_thumb_is_hovered  = txtbox->scrollbar_fade_hovered_onoff  = FALSE;
	txtbox->scrollbar_thumb_is_captured = txtbox->scrollbar_fade_captured_onoff = FALSE;


	txtbox->caret_pt = NSMakePoint( 0, 0 );

	txtbox->caret_fr = NonnonMakeCaret( 0,0,0,0 );
	txtbox->caret_to = NonnonMakeCaret( 0,0,0,0 );

	txtbox->caret_blink_onoff       = TRUE;
	txtbox->caret_blink_force_onoff = FALSE;

	n_bmp_fade_init( &txtbox->caret_blink_fade, n_bmp_black );

	txtbox->shift_selection_is_tail = TRUE;

#ifdef N_TXTBOX_IME_ENABLE

	txtbox->ime_caret_fr = txtbox->caret_fr;
	txtbox->ime_caret_to = txtbox->caret_to;

	txtbox->ime_freed = FALSE;

#endif


	[self NonnonTxtboxEditedNotify:FALSE];


	n_bmp_fade_init( &txtbox->delete_circle_fade_hovered, n_bmp_black );
	n_bmp_fade_init( &txtbox->delete_circle_fade_pressed, n_bmp_black );


	txtbox->crlf_nsstring = @"\xe2\x86\xa9";

	txtbox->crlf_pixel_size = n_mac_image_text_pixelsize( txtbox->crlf_nsstring, txtbox->linenumber_font );

	txtbox->crlf_ox = ( txtbox->font_size.width  - txtbox->crlf_pixel_size.width  ) / 2;
	txtbox->crlf_oy = ( txtbox->font_size.height - txtbox->crlf_pixel_size.height ) / 2;

	txtbox->crlf_ox += 4;
	//txtbox->crlf_oy += 4;


	txtbox->redraw_fy = -1;
	txtbox->redraw_ty = -1;

}

- (void) NonnonTxtboxFocus2Caret
{

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
	n_type_int    cch  = n_posix_strlen( line );

	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		cch
	);

	[self NonnonTxtboxCaretOutOfCanvasUpDown];

}




- (CGFloat) NonnonTxtboxFocusCalculate:(NSPoint) local_point
{
	return n_txtbox_round( txtbox->scr.unit_pos ) + n_txtbox_round( ( local_point.y - txtbox->offset_y ) / txtbox->font_size.height );
}

- (n_caret) NonnonTxtboxMouseCursorDetect
{

	NSPoint local_point = n_mac_cursor_position_get( self );

	txtbox->focus = [self NonnonTxtboxFocusCalculate:local_point];
	if ( txtbox->focus < 0 ) { txtbox->focus = 0; }
	if ( txtbox->focus >= txtbox->txt_data->sy ) { txtbox->focus = txtbox->txt_data->sy - 1; }
//NSLog( @"%f", txtbox->focus );

	NSRect r = NSMakeRect( txtbox->padding, txtbox->offset_y, [self frame].size.width - ( txtbox->offset_x * 2 ), txtbox->font_size.height );

	n_caret caret = n_txtbox_caret_detect_pixel2caret
	(
		txtbox->txt_data,
		txtbox->focus,
		r,
		txtbox->font,
		txtbox->font_size,
		local_point
	);

//NSLog( @"%lld %lld", caret.cch.x, caret.cch.y );


	return caret;
}




- (void) _NonnonTxtboxScrollbarTimer
{

	if ( txtbox->smooth_wheel_mutex ) { return; }


	if ( txtbox->scrollbar_fade_captured_onoff )
	{
		n_bmp_fade_engine( &txtbox->scrollbar_fade, TRUE );
//NSLog( @"%d", scrollbar_fade.percent );
		if ( txtbox->scrollbar_fade.stop == FALSE )
		{
			[self NonnonTxtboxRedraw];
		} else {
			txtbox->scrollbar_fade_captured_onoff = FALSE;
		}

		return;
	}


//return;

	static BOOL prv = FALSE;

	BOOL cur = n_mac_window_is_hovered_offset_by_rect( self, txtbox->scrollbar_thumb_rect );
//NSLog( @"fade %d %d %d", prv, cur, thumb_is_hovered );

	if ( ( prv == FALSE )&&( cur )&&( txtbox->scrollbar_thumb_is_hovered == FALSE ) )
	{
//NSLog( @"fade in" );
		txtbox->scrollbar_thumb_is_hovered = TRUE;

		txtbox->scrollbar_fade_hovered_onoff = TRUE;
		n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
	} else
	if ( ( cur == FALSE )&&( txtbox->scrollbar_thumb_is_hovered ) )
	{
//NSLog( @"fade out" );
		txtbox->scrollbar_thumb_is_hovered = FALSE;

		txtbox->scrollbar_fade_hovered_onoff = TRUE;
		n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
	} 

	n_bmp_fade_engine( &txtbox->scrollbar_fade, TRUE );
//NSLog( @"%d", scrollbar_fade.percent );

	if ( txtbox->scrollbar_fade.stop == FALSE )
	{
		[self NonnonTxtboxRedraw];
	} else {
		txtbox->scrollbar_fade_hovered_onoff = FALSE;
	}

	prv = txtbox->scrollbar_thumb_is_hovered;

}




- (void) NonnonTxtboxUndo:(int) action
{

	if ( action == N_TXTBOX_UNDO_RESTORE )
	{
		n_txt_copy( &txtbox->undo.txt, txtbox->txt_data );

		txtbox->scr.unit_pos = txtbox->undo.scroll;
		txtbox->focus        = txtbox->undo.focus;
		txtbox->caret_fr     = txtbox->undo.caret_fr;
		txtbox->caret_to     = txtbox->undo.caret_to;
	} else
	if ( action == N_TXTBOX_UNDO_REGISTER )
	{
		n_txt_copy( txtbox->txt_data, &txtbox->undo.txt );

		txtbox->undo.scroll   = txtbox->scr.unit_pos;
		txtbox->undo.focus    = txtbox->focus;
		txtbox->undo.caret_fr = txtbox->caret_fr;
		txtbox->undo.caret_to = txtbox->caret_to;
	}

}

- (void) _NonnonTxtboxCaretBlinkTimer
{
//return;

	if ( FALSE == n_mac_window_is_keywindow( self.window ) ) { return; }


	if ( self.txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		if ( self.txtbox->listbox_edit_onoff == FALSE ) { return; }
	}


	if ( n_bmp_ui_timer( &txtbox->caret_blink_interval, 500 ) )
	{
		n_bmp_fade_init( &txtbox->caret_blink_fade, n_bmp_black );
		if ( txtbox->caret_blink_onoff )
		{
			n_bmp_fade_go( &txtbox->caret_blink_fade, n_bmp_white );
			txtbox->caret_blink_onoff = txtbox->caret_blink_force_onoff = FALSE;
		} else {
			n_bmp_fade_go( &txtbox->caret_blink_fade, n_bmp_white );
			txtbox->caret_blink_onoff =  TRUE;
		}
	}

	n_bmp_fade_engine( &txtbox->caret_blink_fade, TRUE );


//return;

//NSLog( @"!" );
	if ( self.txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
//NSLog( @"N_MAC_TXTBOX_MODE_FINDBOX" );
		[self NonnonTxtboxRedraw];
	} else
	if ( txtbox->grab_n_drag_onoff )
	{
//NSLog( @"grab_n_drag_onoff" );
		[self NonnonTxtboxRedraw];
	} else
	if ( txtbox->drag_timer_queue )
	{
//NSLog( @"drag_timer_queue" );
		[self NonnonTxtboxRedraw];
	} else
	if ( txtbox->is_key_input )
	{
//NSLog( @"is_key_input" );
		[self NonnonTxtboxRedraw];
	} else
	if ( txtbox->ime_onoff )
	{
//NSLog( @"IME" );
		[self NonnonTxtboxRedrawPartial];
	} else
	//
	{
//NSLog( @"N/A" );
		[self NonnonTxtboxRedraw];
	}

}

- (void) _NonnonTxtboxDeleteCircleTimer
{

	if ( self.txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		BOOL redraw = FALSE;

		n_bmp_fade_engine( &txtbox->find_icon_fade, TRUE );
		if ( txtbox->find_icon_fade.stop == FALSE ) { redraw = TRUE; }

		n_bmp_fade_engine( &txtbox->delete_circle_fade_hovered, TRUE );
		if ( txtbox->delete_circle_fade_hovered.stop == FALSE ) { redraw = TRUE; }

		if ( txtbox->delete_circle_fade_pressed_phase == 1 )
		{
			txtbox->delete_circle_fade_pressed_phase++;
			n_bmp_fade_always_on( &txtbox->delete_circle_fade_pressed, n_bmp_black, n_bmp_white );
		}

		if ( txtbox->delete_circle_fade_pressed_phase == 2 )
		{
			n_bmp_fade_engine( &txtbox->delete_circle_fade_pressed, TRUE );
			if ( txtbox->delete_circle_fade_pressed.stop )
			{
				txtbox->delete_circle_fade_pressed_phase = 0;

				[self NonnonTxtboxSelectAll:FALSE];
				n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to );

				[txtbox->ime discardMarkedText];
				txtbox->ime_nsstr = @"";
				txtbox->ime_onoff = FALSE;

				if ( delegate_option & N_MAC_TXTBOX_DELEGATE_DELETE )
				{
					[self.delegate NonnonTxtbox_delegate_delete:self];
				}

				txtbox->caret_blink_interval     = 0;
				txtbox->caret_blink_onoff        = txtbox->caret_blink_force_onoff = FALSE;
				txtbox->caret_blink_fade.percent = 100;
			}

			redraw = TRUE;
		}

		if ( redraw ) { [self NonnonTxtboxRedraw]; }
	}

}

- (void) _NonnonTxtboxDragTimer
{

	if ( txtbox->drag_timer_queue )
	{
		NSPoint pt = n_mac_cursor_position_get( self );
//NSLog( @"%f %f", pt.y, [self frame].size.height );

		if ( pt.y <= 0 )
		{
			CGFloat boost = 1 + ( fabs( pt.y ) / 100 );
			txtbox->scr.unit_pos -= boost;
		} else
		if ( pt.y >= [self frame].size.height )
		{
			CGFloat boost = 1 + ( fabs( pt.y - [self frame].size.height ) / 100 );
			txtbox->scr.unit_pos += boost;
		}

		txtbox->caret_to = [self NonnonTxtboxMouseCursorDetect];

		[self NonnonTxtboxRedraw];
	}

}

- (void) _NonnonTxtboxSmoothWheelTimer
{

	if ( txtbox->smooth_wheel_is_mos ) { return; }

	if ( txtbox->smooth_wheel_onoff )
	{
		CGFloat delta = fabs( txtbox->smooth_wheel_delta );
		if ( delta == 0 ) { return; }
//NSLog( @"%0.2f", delta );

		// [!] : small amount support : Mos hasn't this feature

		static BOOL slow = FALSE;

		if ( txtbox->smooth_wheel_animation_onoff == FALSE )
		{
			txtbox->smooth_wheel_animation_onoff = TRUE;
			txtbox->smooth_wheel_animation_timer = n_posix_tickcount();
			txtbox->smooth_wheel_animation_count = 0;
			txtbox->smooth_wheel_animation_msec  = 0;

//NSLog( @"%0.2f", delta );
			if ( delta <= 3 )
			{
				slow = TRUE;
			}
		}

		if ( txtbox->smooth_wheel_animation_onoff )
		{
			txtbox->smooth_wheel_animation_msec = n_posix_min( pow( delta, 3 ), 300 );
		}
//NSLog( @"slow %d : %d msec : delta %0.2f", slow, smooth_wheel_animation_msec, delta );

		if ( txtbox->smooth_wheel_animation_onoff )
		{
			if ( txtbox->smooth_wheel_delta < 0 )
			{
				txtbox->scr.unit_pos += 1;
			} else {
				txtbox->scr.unit_pos -= 1;
			}

			[self NonnonTxtboxRedraw];

			BOOL go = FALSE;
			if ( slow )
			{
//NSLog( @"slow" );
				txtbox->smooth_wheel_animation_count++;
				if ( txtbox->smooth_wheel_animation_count >= 3 )
				{
					go = TRUE;
				}
			} else
			if ( n_bmp_ui_timer( &txtbox->smooth_wheel_animation_timer, txtbox->smooth_wheel_animation_msec ) )
			{
//NSLog( @"fast" );
				go = TRUE;
			}

			if ( go )
			{
				txtbox->smooth_wheel_animation_onoff = FALSE;

				txtbox->smooth_wheel_onoff = FALSE;
				txtbox->smooth_wheel_mutex = FALSE;

				slow = FALSE;
			}
		}

	}

}
/*
- (void) _NonnonTxtboxTestTimer
{

	NSRect rect = NSMakeRect( 0,0,200,200 );
	[self displayRect:rect];

}
*/



- (void) NonnonTxtboxKeyboardInputMethod:(NSString*)nsstring
{
//return;

	// [x] : don't make undo buffer : [self NonnonTxtboxUndo:N_TXTBOX_UNDO_REGISTER];


	if ( txtbox->txt_data->readonly ) { return; }


#ifdef N_TXTBOX_IME_ENABLE

	BOOL is_tab = FALSE;
	{
		n_posix_char *s = n_mac_nsstring2str( nsstring );
		if ( s[ 0 ] == N_STRING_CHAR_TAB )
		{
//NSLog( @"tab" );
			is_tab = TRUE;
		}

		n_string_free( s );
	}

	if ( is_tab == FALSE )
	{
		[self NonnonTxtboxRedraw];

		return;
	}

#endif


	n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to );
//return;


	n_posix_char *line_f = n_string_carboncopy( n_txt_get( txtbox->txt_data, txtbox->focus ) );
	n_posix_char *line_m = n_mac_nsstring2str( nsstring );
	n_posix_char *line_t = n_string_carboncopy( n_txt_get( txtbox->txt_data, txtbox->focus ) );

	line_f[ txtbox->caret_fr.cch.x ] = N_STRING_CHAR_NUL;
	n_posix_snprintf_literal( line_t, n_posix_strlen( n_txt_get( txtbox->txt_data, txtbox->focus ) ) + 1, "%s", &line_t[ txtbox->caret_fr.cch.x ] );

	n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( line_m ) + n_posix_strlen( line_t );
	n_posix_char *s   = n_string_new( cch );
	n_posix_snprintf_literal( s, cch + 1, "%s%s%s", line_f, line_m, line_t );
//NSLog( @"%s : %s : %s", line_f, line_m, line_t );

	//NSString *tmp = [[NSString alloc] initWithUTF8String:s];
//NSLog( @"%@", tmp );

	n_txt_mod( txtbox->txt_data, txtbox->focus, s );


	txtbox->caret_fr.cch.x = txtbox->caret_to.cch.x = n_posix_strlen( line_f ) + n_posix_strlen( line_m );

	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		txtbox->caret_fr.cch.x
	);


	n_string_free( s );


	n_string_free( line_f );
	n_string_free( line_m );
	n_string_free( line_t );


	[self NonnonTxtboxEditedNotify:TRUE];


	[self NonnonTxtboxRedraw];

}




- (void) NonnonTxtboxCaretTailSet
{

	txtbox->caret_fr = txtbox->caret_to = n_mac_txtbox_caret_tail
	(
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		&txtbox->shift_selection_is_tail
	);

}

- (void) NonnonTxtboxTripleclickDetect
{
//NSLog( @"%f", txtbox->focus );

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
	n_type_int    cch  = n_posix_strlen( line );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		cch
	);


	txtbox->caret_fr = NonnonMakeCaret
	(
		0, txtbox->focus * txtbox->font_size.height,
		0, txtbox->focus
	);

	txtbox->caret_to = NonnonMakeCaret
	(
		caret.pxl.x, txtbox->focus * txtbox->font_size.height,
		cch, txtbox->focus
	);

	txtbox->shift_selection_is_tail = TRUE;


	return;
}

- (void) NonnonTxtboxDoubleclickDetect:(BOOL)smart_selection_onoff tab_patch:(BOOL)tab_patch
{
//return;

	// [x] : Xcode : bug : japanese characters are not output

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
//NSLog( @"%lld : %s", txtbox->focus, line ); return;
//NSLog( @"%c", line[ caret_fr.cch.x ] );

	if (
		( smart_selection_onoff )
		&&
		( n_mac_txtbox_selection_is_stop_char_single_utf8_search( &line[ txtbox->caret_fr.cch.x ], "　" ) )
	)
	{
//NSLog( @"zenkaku sapce" );

		n_type_int cch_space = n_posix_strlen( "　" );

		{

			n_type_int cch_fr = txtbox->caret_fr.cch.x;
			n_posix_loop
			{
				if ( cch_fr <= 0 ) { break; }

				if ( FALSE == n_mac_txtbox_selection_is_stop_char_single_utf8_search( &line[ cch_fr ], "　" ) )
				{
					cch_fr += cch_space;
					break;
				}

				cch_fr -= cch_space;
			}


			txtbox->caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_fr
			);

		}

		{

			n_type_int cch_to = txtbox->caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == '\0' ) { break; }

				if ( FALSE == n_mac_txtbox_selection_is_stop_char_single_utf8_search( &line[ cch_to ], "　" ) )
				{
					break;
				}

				cch_to += cch_space;
			}


			txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_to
			);

		}

	} else
	if (
		( line[ txtbox->caret_fr.cch.x ] ==  ' ' )
		||
		( line[ txtbox->caret_fr.cch.x ] == '\t' )
		||
		(
			( tab_patch )
			&&
			( ( txtbox->caret_fr.cch.x > 0 )&&( line[ txtbox->caret_fr.cch.x - 1 ] == '\t' ) )
		)
	)
	{
//NSLog( @"blank" );

		if (
			( tab_patch )
			&&
			( ( txtbox->caret_fr.cch.x > 0 )&&( line[ txtbox->caret_fr.cch.x - 1 ] == '\t' ) )
		)
		{
			txtbox->caret_fr.cch.x--;
		}

		{

			n_type_int cch_fr = txtbox->caret_fr.cch.x;
			n_posix_loop
			{
				if ( cch_fr <= 0 ) { break; }

//NSLog( @"%c", line[ cch_fr ] );

				if (
					( line[ cch_fr ] !=  ' ' )
					&&
					( line[ cch_fr ] != '\t' )
				)
				{
					cch_fr++;
					break;
				}

				cch_fr--;
			}


			txtbox->caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_fr
			);

		}

		{

			n_type_int cch_to = txtbox->caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == '\0' ) { break; }

				if (
					( line[ cch_to ] !=  ' ' )
					&&
					( line[ cch_to ] != '\t' )
				)
				{
					break;
				}

				cch_to++;
			}


			txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_to
			);

		}

	} else {
//NSLog( @"non-blank : %s : %c", line, line[ caret_fr.cch.x ] );

		n_posix_char *starting_char     = &line[ txtbox->caret_fr.cch.x ];
		n_type_int    starting_char_cch = n_mac_txtbox_utf8_cb( starting_char );
//NSLog( @"%lld", starting_char_cch );

		{

			n_type_int cch_fr = txtbox->caret_fr.cch.x;
//NSLog( @"start %c", line[ cch_fr ] );

			n_posix_loop
			{
				if ( cch_fr < 0 ) { cch_fr = 0; break; }

				n_type_int step = n_mac_txtbox_utf8_cb( &line[ cch_fr ] );

				if (
					( line[ cch_fr ] ==  ' ' )
					||
					( line[ cch_fr ] == '\t' )
					||
					(
						( smart_selection_onoff )
						&&
						(
							( starting_char_cch != step )
							||
							( n_mac_txtbox_selection_is_stop_char_utf8( starting_char, &line[ cch_fr ] ) )
							||
							( n_mac_txtbox_digit_detect( starting_char, line, cch_fr ) )
						)
					)
				)
				{
					cch_fr += step;
					break;
				}

				BOOL break_needed = FALSE;

				u8 *str = (u8*) line;
				n_posix_loop
				{
					if ( cch_fr <= 0 ) { cch_fr = 0; break_needed = TRUE; break; }

					cch_fr--;

					if ( str[ cch_fr ] >= 0xf0 )
					{
						break;
					} else
					if ( str[ cch_fr ] >= 0xe0 )
					{
						break;
					} else
					if ( str[ cch_fr ] >= 0xc0 )
					{
						break;
					} else
					if ( str[ cch_fr ] <= 127 )
					{
						break;
					}

				}

				if ( break_needed ) { break; }
			}

			txtbox->caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_fr
			);

//NSLog( @"%c", line[ cch_fr ] );

		}

		{

			n_type_int cch_to = txtbox->caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == '\0' ) { break; }

				n_type_int step = n_mac_txtbox_utf8_cb( &line[ cch_to ] );

				if (
					( line[ cch_to ] ==  ' ' )
					||
					( line[ cch_to ] == '\t' )
					||
					(
						( smart_selection_onoff )
						&&
						(
							( starting_char_cch != step )
							||
							( n_mac_txtbox_selection_is_stop_char_utf8( starting_char, &line[ cch_to ] ) )
							||
							( n_mac_txtbox_digit_detect( starting_char, line, cch_to ) )
						)
					)
				)
				{
//NSLog( @"To : found %@", n_mac_str2nsstring( &line[ cch_to ] ) );
					break;
				}

				cch_to += step;
			}


			txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_to
			);

		}

	}


	txtbox->shift_selection_is_tail = TRUE;


//n_caret_debug_cch( caret_fr, caret_to );
	return;	
}




-(void) NonnonTxtboxCaretOutOfCanvasUpDownSearch
{
//NSLog( @"NonnonTxtboxCaretOutOfCanvasUpDown" );

	CGFloat minim = MIN( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );
	CGFloat maxim = MAX( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );
//NSLog( @"%f %f %f", minim, maxim, scroll );

	if ( minim < txtbox->scr.unit_pos )
	{
//NSLog( @"up" );
		txtbox->scr.unit_pos = minim - ( txtbox->scr.unit_page / 2 );
	} else
	if ( maxim >= ( txtbox->scr.unit_pos + txtbox->scr.unit_page - 1 ) )
	{
		txtbox->scr.unit_pos = maxim - ( txtbox->scr.unit_page / 2 );
	}

}

-(void) NonnonTxtboxCaretOutOfCanvasUpDown
{

	// [!] : Line Scroller

	if ( txtbox->focus < txtbox->scr.unit_pos )
	{
		CGFloat d = fabs( txtbox->focus - trunc( txtbox->scr.unit_pos ) );
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%lld %f", txtbox->focus, txtbox->scr.unit_pos );
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%f", d );

		if ( d == 1.0 )
		{
			txtbox->scr.unit_pos -= txtbox->scr.unit_step;
		} else
		if ( d > 1.0 )
		{
			[self NonnonTxtboxCaretOutOfCanvasUpDownSearch];
		}
	}

	const CGFloat csy   = self.frame.size.height;
	const CGFloat base  = csy - ( txtbox->offset_y * 2 );
	const CGFloat focus = ( txtbox->focus - txtbox->scr.unit_pos + 1 ) * txtbox->font_size.height;
//NSLog( @"%f %f", base - focus, txtbox->font_size.height );

	if ( ( base - focus ) < 0 )
	{
		if ( fabs( base - focus ) < txtbox->font_size.height )
		{
			txtbox->scr.unit_pos += txtbox->scr.unit_step;
		} else
		if ( fabs( base - focus ) < ( txtbox->font_size.height * 2 ) )
		{
			txtbox->scr.unit_pos += txtbox->scr.unit_step * 2;
		} else {
			[self NonnonTxtboxCaretOutOfCanvasUpDownSearch];
		}
	}

}

-(void) NonnonTxtboxCaretOutOfCanvasUpDownSwap
{

	// [!] : Line Scroller

	s64 focus = txtbox->focus + 1;

	if ( focus < txtbox->scr.unit_pos )
	{
		txtbox->scr.unit_pos -= txtbox->scr.unit_step;
	}

//NSLog( @"%lld %f", txtbox->focus, txtbox->scr.unit_pos + txtbox->scr.unit_page );
	if ( focus >= ( txtbox->scr.unit_pos + txtbox->scr.unit_page ) )
	{
		txtbox->scr.unit_pos += txtbox->scr.unit_step;
	}

}

-(void) NonnonTxtboxPageUpDown:(int)updown
{

	if ( self.txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX ) { return; }
	if ( self.txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE ) { return; }


	if ( updown == 0 ) { return; }


	txtbox->scr.pixel_pos = trunc( txtbox->scr.pixel_pos / txtbox->scr.pixel_step ) * txtbox->scr.pixel_step;
	txtbox->scr. unit_pos = ( txtbox->scr.pixel_pos  / txtbox->scr.pixel_max ) * txtbox->scr.unit_max;

	if ( updown <= -1 )
	{
		txtbox->scr.unit_pos -= trunc( txtbox->scr.unit_page );
	} else
	if ( updown >=  1 )
	{
		txtbox->scr.unit_pos += trunc( txtbox->scr.unit_page );
	}

	[self NonnonTxtboxRedraw];

}




- (void) NonnonTxtboxInsert:(NSString*)nsstring
{
//return;
//NSLog( @"modified cch : %lld", ime_caret_fr.cch.x );

	if ( txtbox->txt_data->readonly ) { return; }


	if ( self.txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		if ( self.txtbox->listbox_edit_onoff == FALSE ) { return; }
	}


	n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to );


	txtbox->ime_caret_fr = txtbox->caret_fr;
	txtbox->ime_caret_to = txtbox->caret_to;


//n_caret_debug_cch( caret_fr, caret_to );

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );

	n_posix_char *line_f = n_string_carboncopy( line );
	n_posix_char *line_m = n_mac_nsstring2str( nsstring );
	n_posix_char *line_t = n_string_carboncopy( line );

//NSLog( @"modified : %s : %@", line_f, n_mac_str2nsstring( line_t ) );


	n_type_int cch_f = n_posix_strlen( line_f );
	n_type_int cch_m = n_posix_strlen( line_m );
	n_type_int cch_t = n_posix_strlen( line_t );


	n_posix_char *mod = n_string_new( cch_f + cch_m + cch_t );

	if ( txtbox->ime_caret_fr.cch.x < cch_f )
	{
		line_f[ txtbox->ime_caret_fr.cch.x ] = N_STRING_CHAR_NUL;
	}
//NSLog( @"%s", line_f );

	n_type_int cch_cut = txtbox->ime_caret_to.cch.x;
//NSLog( @"cch_cut : %lld", cch_cut );

	if ( ( cch_cut >= 0 )&&( cch_cut < cch_f ) )
	{
		n_posix_snprintf_literal( line_t, cch_t + 1, "%s", &line_t[ cch_cut ] );
	} else {
		n_string_truncate( line_t );
	}

	n_posix_snprintf_literal( mod, cch_f + cch_m + cch_t + 1, "%s%s%s", line_f, line_m, line_t );
//NSLog( @"%s : %s : %s", line_f, line_m, line_t );

	n_txt_mod_fast( txtbox->txt_data, txtbox->focus, mod );


	n_string_free( line_f );
	n_string_free( line_m );
	n_string_free( line_t );


	[self NonnonTxtboxCaretOutOfCanvasUpDown];


	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		txtbox->ime_caret_fr.cch.x + cch_m
	);

	txtbox->ime_caret_fr = txtbox->caret_fr;
	txtbox->ime_caret_to = txtbox->caret_to;


	[self NonnonTxtboxEditedNotify:TRUE];


	return;
}

- (void) NonnonTxtboxSelectAll:(BOOL)redraw
{

	txtbox->caret_fr = NonnonMakeCaret( 0, 0, 0, 0 );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->txt_data,
		txtbox->txt_data->sy - 1,
		txtbox->font,
		txtbox->font_size,
		n_posix_strlen( n_txt_get( txtbox->txt_data, txtbox->txt_data->sy - 1 ) )
	);

	txtbox->caret_to = NonnonMakeCaret
	(
		caret.pxl.x,
		( (CGFloat) txtbox->txt_data->sy - 1 ) * txtbox->font_size.height,
		caret.cch.x,
		txtbox->txt_data->sy - 1
	);

	if ( redraw )
	{
		[self NonnonTxtboxRedraw];
	}


	return;
}



/*
- (void) applicationWillBecomeActive:(NSNotification *)notification
{
//NSLog( @"applicationWillBecomeActive" );

	is_grayed = NO;
	[self NonnonTxtboxRedraw];

}

- (void) applicationWillResignActive:(NSNotification *)notification
{
//NSLog( @"applicationWillResignActive" );

	is_grayed = YES;
	[self NonnonTxtboxRedraw];

}
*/



#ifdef N_TXTBOX_IME_ENABLE

- (BOOL)hasMarkedText;
{
//NSLog( @"hasMarkedText" );

	return NO;
}

- (NSRange)markedRange
{
//NSLog( @"markedRange" );

	NSRange range = { NSNotFound, 0 };
	return range;
}

- (NSRange)selectedRange
{
//NSLog( @"selectedRange" );

	NSRange range = { NSNotFound, 0 };
	return range;
}

- (void)setMarkedText:(id)string 
        selectedRange:(NSRange)selectedRange 
     replacementRange:(NSRange)replacementRange
{
//NSLog( @"setMarkedText : %@", [string string] );

//NSLog( @"setMarkedText : Set     %lu %lu",    selectedRange.location,    selectedRange.length );
//NSLog( @"setMarkedText : Replace %lu %lu", replacementRange.location, replacementRange.length );


	// [x] : buggy : when IME is OFF : no insertText is sent
	txtbox->ime_is_first = FALSE;


	BOOL prv_onoff = txtbox->ime_onoff;

	txtbox->ime_nsstr = [[string string] copy];
	txtbox->ime_onoff = ( [txtbox->ime_nsstr length] != 0 );
	txtbox->ime_freed = FALSE;
	txtbox->ime_delay = FALSE;
	txtbox->ime_focus = selectedRange;

	txtbox->ime_caret_offset = selectedRange.location + selectedRange.length;

//NSLog( @"NSString : %@", ime_nsstr );


	if ( txtbox->ime_onoff )
	{
		if ( prv_onoff == FALSE ) { txtbox->ime_caret_fr = txtbox->caret_fr; }
		txtbox->ime_caret_to = txtbox->caret_fr;

		[self NonnonTxtboxRedraw];
	}


	return;
}

- (void)unmarkText
{
//NSLog( @"unmarkText" );

	return;
}

- (NSArray<NSAttributedStringKey> *)validAttributesForMarkedText
{
//NSLog( @"validAttributesForMarkedText" );

	return [[NSArray alloc] init];
}

- (NSAttributedString *)attributedSubstringForProposedRange:(NSRange)range 
                                                actualRange:(NSRangePointer)actualRange
{
//NSLog( @"attributedSubstringForProposedRange" );

	return nil;
}

- (void)insertText:(id)string 
  replacementRange:(NSRange)replacementRange
{
//NSLog( @"insertText" );
//NSLog( @"insertText : %lu %lu", replacementRange.location, replacementRange.length );

//NSLog( @"insertText : %d : %@ : %@", ime_is_first, string, ime_nsstr );

	// [x] : buggy : when IME is OFF : no insertText is sent
	txtbox->ime_is_first = TRUE;

	txtbox->ime_delay = txtbox->ime_onoff;

	[txtbox->ime discardMarkedText];
	txtbox->ime_nsstr = @"";
	txtbox->ime_onoff = FALSE;

	[self NonnonTxtboxUndo:N_TXTBOX_UNDO_REGISTER];
	[self NonnonTxtboxInsert:string];


	return;
}

- (NSUInteger)characterIndexForPoint:(NSPoint)point
{
//NSLog( @"characterIndexForPoint" );

	return 0;
}

- (NSRect)firstRectForCharacterRange:(NSRange)range 
                         actualRange:(NSRangePointer)actualRange
{
//NSLog( @"firstRectForCharacterRange" );
//NSLog( @"firstRectForCharacterRange : %@", NSStringFromRange( range ) );


	n_posix_char *str = n_mac_nsstring2str( txtbox->ime_nsstr );
	//n_type_int    cch = n_posix_strlen( str );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		txtbox->ime_caret_fr.cch.x// + cch
	);

	n_string_free( str );


	// [Needed] : composition popup needs trunc()
//NSLog( @"%f", fmod( scroll, 1 ) );

	CGFloat ox = caret.pxl.x + txtbox->padding;
	CGFloat oy = caret.pxl.y - ( n_txtbox_round( txtbox->scr.unit_pos ) * txtbox->font_size.height );
	//CGFloat yy = NSHeight( [ [self.window screen] visibleFrame ] );
//NSLog( @" %0.2f %0.2f : %0.2f : %0.2f ", ox, oy, yy, scroll );


	// [x] : oy : offset is not needed when popup moves to upper side

	ox += txtbox->offset_x;
	oy += txtbox->offset_y + txtbox->font_size.height;

//NSLog( @" %0.2f %0.2f : %0.2f : %0.2f ", ox, oy, yy, scroll );


	NSPoint point         = NSMakePoint( ox, oy );
	NSPoint pointInWindow = [self convertPoint:point toView:nil];
	NSRect  rect          = NSMakeRect( pointInWindow.x, pointInWindow.y, 0, 0 );
	NSRect  pointOnScreen = [[self window] convertRectToScreen:rect];

//NSLog( @" %0.2f %0.2f ", pointOnScreen.origin.x, pointOnScreen.origin.y );


	return pointOnScreen;
}

- (void)doCommandBySelector:(SEL)selector
{
//NSLog( @"doCommandBySelector" );

	return;
}
#endif




@end




#include "n_txtbox/07_dnd.c"
#include "n_txtbox/08_draw.c"
#include "n_txtbox/09_search.c"
#include "n_txtbox/10_keyboard.c"
#include "n_txtbox/11_mouse.c"




#endif // _H_NONNON_MAC_NONNON_TXTBOX


